//
//  AppDelegate+Authentication.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

extension AppDelegate {

    // MARK: - User Authentication
    
    func initAppRootViewController() {

        Q_NotificationObserverAdd(self, #selector(userAccessTokenAuthSuccessAction(n:)), USER_TOKEN_AUTHENTICATION_SUCCESS_NOTIFICATION)
        Q_NotificationObserverAdd(self, #selector(userAccessTokenAuthFailureAction(n:)), USER_TOKEN_AUTHENTICATION_FAILURE_NOTIFICATION)
        
        Q_NotificationObserverAdd(self, #selector(userLoginAuthSuccessAction(n:)), USER_LOGIN_AUTHENTICATION_SUCCESS_NOTIFICATION)
        Q_NotificationObserverAdd(self, #selector(userLogoutAuthSuccessAction(n:)), USER_LOGOUT_AUTHENTICATION_SUCCESS_NOTIFICATION)
        
        /// 验证 AccessToken
        userAccessTokenAuth()
    }
    
    // MARK: Access Token Authentication
    
    func userAccessTokenAuth() {
        
        // accessToken 验证
        if UserSession.CurrentSession().hasValidAccessToken == true {
            Q_NotificationPost(USER_TOKEN_AUTHENTICATION_SUCCESS_NOTIFICATION, nil)
        } else {
            Q_NotificationPost(USER_TOKEN_AUTHENTICATION_FAILURE_NOTIFICATION, nil)
        }
    }
    
    @objc func userAccessTokenAuthSuccessAction(n: NSNotification) {
        
        userAuthSuccessAction()
    }

    @objc func userAccessTokenAuthFailureAction(n: NSNotification) {
        
        userAuthFailureAction()
    }
    
    // MARK: Login / Logout Authentication
    
    @objc func userLoginAuthSuccessAction(n: NSNotification) {

        userAuthSuccessAction()
    }

    @objc func userLogoutAuthSuccessAction(n: NSNotification) {

        userAuthFailureAction()
    }
    
    // MARK: Authentication Action
    
    func userAuthSuccessAction() {
        
        setAppRootViewController(withStroyboard: StroyboardType.main.rawValue)
    }

    func userAuthFailureAction() {
        
        setAppRootViewController(withStroyboard: StroyboardType.authentication.rawValue)
        AuthenticationLogoutDataSourceService().clearLocalCacheDatas()
    }
    
    // MARK: Set App Root VC
    
    func setAppRootViewController(withStroyboard sbName: String) {
        
        if sbName == StroyboardType.main.rawValue {
            setAppRootVCToMainVC()
        } else {
            setAppRootVCToAuthenticationVC()
        }
    }
    
    func setAppRootVCToMainVC() {
        
        let sb: UIStoryboard = UIStoryboard(name: StroyboardType.main.rawValue, bundle: nil)
        self.window?.rootViewController = sb.instantiateInitialViewController()! as? UINavigationController
    }
    
    func setAppRootVCToAuthenticationVC() {
        
        let sb: UIStoryboard = UIStoryboard(name: StroyboardType.authentication.rawValue, bundle: nil)
        self.window?.rootViewController = sb.instantiateInitialViewController()! as? UINavigationController
    }
    
}
