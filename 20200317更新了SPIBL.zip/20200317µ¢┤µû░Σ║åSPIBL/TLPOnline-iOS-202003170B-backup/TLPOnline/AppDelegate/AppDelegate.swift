//
//  AppDelegate.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    
    var window: UIWindow?
    
    
    // MARK: - Private Property
    
    var application: UIApplication!
    var launchOptions: [UIApplicationLaunchOptionsKey: Any]?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        let InstaransObject:MAC = MAC()
        
        let UUIDinfo = InstaransObject.getUUID()
        
        self.application = application
        self.launchOptions = launchOptions
        
        
        
        
        //print("Device UUID Number \(UUIDinfo ?? "1AED2D4C-73B8-4187-80F6-C0B62D1F15D6")")
        //print("Device UUID Number \(UUIDinfo ?? "173CC94F-03D0-4DB3-BE59-22EEFA86228F")")
        print("Device UUID Number \(UUIDinfo ?? "unknown_UUID")")
        
        /*
        let info = QAppMonitor.shared().q_appDeviceInfo()
        let baseUrl = Q_UserDefaultsObjectGet(API_ROOT_URL_KEY) as? String ?? API_ROOT_DEFAULT_URL
        LOG("AppDeviceInfo",
            "\(info)",
            "",
            " -----------------",
            "",
            " API Base URL            : \(baseUrl)"
            )
        */
        
        initNetWorkMonitor()
        initIQKeyboard()
        
        initAppRootViewController()
        
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        
    }

}
