//
//  MAC.h
//  UUID
//
//  Created by 李博 on 2020/1/13.
//  Copyright © 2020 yunzujia. All rights reserved.
//

#ifndef MAC_h
#define MAC_h
#import <Foundation/Foundation.h>
#import <ifaddrs.h>
#import <resolv.h>
#import <arpa/inet.h>
#import <net/if.h>
#import <netdb.h>
#import <netinet/ip.h>
#import <net/ethernet.h>
#import <net/if_dl.h>
#import <sys/sysctl.h>
#import <sys/ioctl.h>
#import <net/if.h>
#import <net/if_dl.h>

#define MDNS_PORT       5353
#define QUERY_NAME      "_apple-mobdev2._tcp.local"
#define DUMMY_MAC_ADDR  @"02:00:00:00:00:00"
#define IOS_CELLULAR    @"pdp_ip0"
#define IOS_WIFI        @"en0"
#define IOS_VPN         @"utun0"
#define IP_ADDR_IPv4    @"ipv4"
#define IP_ADDR_IPv6    @"ipv6"
@interface MAC : NSObject

-(NSString *)macAddress;
-(NSString *)getUUID;

@end

#endif /* MAC_h */
