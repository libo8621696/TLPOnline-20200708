//
//  MsgAlertDefinition.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation


/// Alert Title
enum QAlertTitle: String {

    case titleNone
    case titleWarning
    case titleNote
    case titleMessage
    case titlePrompt
}

/// Alert Button Title
enum QAlertButtonTitle: String {

    case titleOK
    case titleNO
}

/**
 *  Alert Show
 *
 *  @param  target          self
 *  @param  title           alert title
 *  @param  msg             alert message
 *  @param  aSelector       action selector
 *  @param  actionBlock     action block
 *
 *  return nil
 */

func QF_AlertShow_Main(_ target: UIViewController,
                        _ title: QAlertTitle,
                          _ msg: String) {

    QF_AlertShow_Main(target, title, msg, nil)
}

func QF_AlertShow_Main(_ target: UIViewController,
                        _ title: QAlertTitle,
                          _ msg: String,
                    _ aSelector: Selector?) {

    Q_AlertControllerAlertActionShow_Main(target,
                                          title.localValue,
                                          msg,
                                          nil,
                                          QAlertButtonTitle.titleOK.localValue, {
                                            if aSelector != nil {
                                                target.perform(aSelector)
                                            }
                                          },
                                          nil,
                                          nil)
}

func QF_AlertShow_Main(_ target: UIViewController,
                        _ title: QAlertTitle,
                          _ msg: String,
                  _ actionBlock: @escaping (() -> Void)) {

    Q_AlertControllerAlertActionShow_Main(target,
                                          title.localValue,
                                          msg,
                                          nil,
                                          QAlertButtonTitle.titleOK.localValue, {
                                            actionBlock()
                                          },
                                          nil,
                                          nil)
}

/**
 *  Alert Warning Show
 *
 *  @param  target          self
 *  @param  msg             alert message
 *  @param  aSelector       action selector
 *  @param  actionBlock     action block
 *
 *  return nil
 */

func QF_AlertShow_Warning_Main(_ target: UIViewController,
                                  _ msg: String) {

    QF_AlertShow_Main(target, QAlertTitle.titleWarning, msg, nil)
}

func QF_AlertShow_Warning_Main(_ target: UIViewController,
                                  _ msg: String,
                            _ aSelector: Selector?) {

    QF_AlertShow_Main(target, QAlertTitle.titleWarning, msg, aSelector)
}

func QF_AlertShow_Warning_Main(_ target: UIViewController,
                                  _ msg: String,
                          _ actionBlock: @escaping (() -> Void)) {

    QF_AlertShow_Main(target, QAlertTitle.titleWarning, msg, actionBlock)
}

/**
 *  Alert Note Show
 *
 *  @param  target          self
 *  @param  msg             alert message
 *  @param  aSelector       action selector
 *  @param  actionBlock     action block
 *
 *  return nil
 */

func QF_AlertShow_Note_Main(_ target: UIViewController,
                               _ msg: String) {

    QF_AlertShow_Main(target, QAlertTitle.titleNote, msg, nil)
}

func QF_AlertShow_Note_Main(_ target: UIViewController,
                               _ msg: String,
                         _ aSelector: Selector?) {

    QF_AlertShow_Main(target, QAlertTitle.titleNote, msg, aSelector)
}

func QF_AlertShow_Note_Main(_ target: UIViewController,
                               _ msg: String,
                       _ actionBlock: @escaping (() -> Void)) {

    QF_AlertShow_Main(target, QAlertTitle.titleNote, msg, actionBlock)
}

/**
 *  Alert Message Show
 *
 *  @param  target          self
 *  @param  msg             alert message
 *  @param  aSelector       action selector
 *  @param  actionBlock     action block
 *
 *  return nil
 */

func QF_AlertShow_Message_Main(_ target: UIViewController,
                                  _ msg: String) {

    QF_AlertShow_Main(target, QAlertTitle.titleMessage, msg, nil)
}

func QF_AlertShow_Message_Main(_ target: UIViewController,
                                  _ msg: String,
                            _ aSelector: Selector?) {

    QF_AlertShow_Main(target, QAlertTitle.titleMessage, msg, aSelector)
}

func QF_AlertShow_Message_Main(_ target: UIViewController,
                                  _ msg: String,
                          _ actionBlock: @escaping (() -> Void)) {

    QF_AlertShow_Main(target, QAlertTitle.titleMessage, msg, actionBlock)
}

/**
 *  Alert Prompt Show
 *
 *  @param  target          self
 *  @param  msg             alert message
 *  @param  aSelector       action selector
 *  @param  actionBlock     action block
 *
 *  return nil
 */

func QF_AlertShow_Prompt_Main(_ target: UIViewController,
                                 _ msg: String) {

    QF_AlertShow_Main(target, QAlertTitle.titlePrompt, msg, nil)
}

func QF_AlertShow_Prompt_Main(_ target: UIViewController,
                                 _ msg: String,
                           _ aSelector: Selector?) {

    QF_AlertShow_Main(target, QAlertTitle.titlePrompt, msg, aSelector)
}

func QF_AlertShow_Prompt_Main(_ target: UIViewController,
                                 _ msg: String,
                         _ actionBlock: @escaping (() -> Void)) {

    QF_AlertShow_Main(target, QAlertTitle.titlePrompt, msg, actionBlock)
}
