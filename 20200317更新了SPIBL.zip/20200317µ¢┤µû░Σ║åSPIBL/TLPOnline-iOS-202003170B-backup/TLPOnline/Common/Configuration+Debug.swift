//
//  Configuration+Debug.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation


/// Debug Log

func LOG(_ title: String?,
         _ items: Any...,
            file: String = #file,
        function: String = #function,
            line: Int = #line) {
    
    var logTitle: String = "\n -----------------\n"
    
    if let tl = title {
        logTitle = "\n --- \(tl) ---\n"
    }
    
    let file    = "--- File  : \((file as NSString).lastPathComponent) ---\n"
    let methods = "--- Method: \(function) ---\n"
    let line    = "--- Line  : \(line) ---\n"
    let data    = "--- Data  : \n"
    let end     = "\n ----------------- \n"
    
    print(logTitle,
          file,
          methods,
          line,
          data)
    
    for obj in items {
        print("\t\(obj)")
    }
    
    print(end)
}
