//
//  EnumTypeDefinition.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation


// MARK: - App Support Language Type

enum AppSupportLanguageType: String {
    
    case sysDefault                         = ""            // 跟随手机系统
    case en                                 = "en"          // English
    case zhHans                             = "zh-Hans"     // 简体中文
}

// MARK: - Change Password Type

enum ChangePasswordType: String {
    
    case newPassword                        = "newPassword" // 新密码
}

// MARK: - Auth Verify Msg Type

enum AuthVerifyMsgType: String {
    
    case serverAddress
    case account
    case password
    case uuid
    
    case airport
    case runway
    case rwCondition
    case antiIce
    case ldgConf
    case breakMode
    case reversers
    case oat
    case qnh
    case wind
    case takeoffW
}

// MARK: - Account Settings Type

enum AccountSettingsType: String {

    case none
    
    case general
    
    case language
    case changePassword
    
    case logOut
}

// MARK: - Calculate Type

enum CalculateType: String {
    
    case none
    
    case takeoff
    case landing
}


/******************************************************************************/


// MARK: - Stroyboard Type

enum StroyboardType: String {
    
    case main                               = "Main"
    case authentication                     = "Authentication"
}

// MARK: - Segue Identifier

enum SegueIdentifier: String {
    
    case settingsDetail                     = "presentSettingsDetailSegue"
    case frmCDL                             = "presentFrmCDLSegue"
}

func QF_PresentViewControllerWithSegueIdentifier(_ target: UIViewController,
                                             _ identifier: SegueIdentifier) {
    
    Q_PresentViewControllerWithSegueIdentifier(target, identifier.rawValue)
}
