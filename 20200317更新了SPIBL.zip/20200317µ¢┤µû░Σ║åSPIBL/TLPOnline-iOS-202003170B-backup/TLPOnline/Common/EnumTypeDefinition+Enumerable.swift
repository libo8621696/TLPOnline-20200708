//
//  EnumTypeDefinition+Enumerable.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation


// MARK: - Protocol Enumerable Enum Type

protocol EnumerableEnumType {
    static var allValues: [Self] {get}
}

// MARK: - App Support Language Type

extension AppSupportLanguageType: EnumerableEnumType {
    
    static var allValues: [AppSupportLanguageType] {
        return [
            .sysDefault,
            .en,
            .zhHans
        ]
    }
}

// MARK: - Change Password Type

extension ChangePasswordType: EnumerableEnumType {
    
    static var allValues: [ChangePasswordType] {
        return [
            .newPassword
        ]
    }
}

// MARK: - Auth Verify Msg Type

extension AuthVerifyMsgType: EnumerableEnumType {
    
    static var allValues: [AuthVerifyMsgType] {
        return [
            .serverAddress,
            .account,
            .password,
            .uuid,
            
            .airport,
            .runway,
            .rwCondition,
            .antiIce,
            .ldgConf,
            .breakMode,
            .reversers,
            .oat,
            .qnh,
            .wind,
            .takeoffW
        ]
    }
}

// MARK: - Account Settings Type

extension AccountSettingsType: EnumerableEnumType {
    
    static var allValues: [AccountSettingsType] {
        return [
            .none,
            .general,
            .language,
            .changePassword,
            .logOut
        ]
    }
}

// MARK: - Calculate Type

extension CalculateType: EnumerableEnumType {
    
    static var allValues: [CalculateType] {
        return [
            .takeoff,
            .landing
        ]
    }
}
