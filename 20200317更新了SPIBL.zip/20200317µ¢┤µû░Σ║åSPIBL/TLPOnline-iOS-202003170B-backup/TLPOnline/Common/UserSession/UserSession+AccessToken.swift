//
//  UserSession+AccessToken.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

extension UserSession {
    
    // MARK: - Internal Property
    
    var hasValidAccessToken: Bool {
        
        reloadUserAccessTokenSession()
        
        guard let expireDate = self.userAccessTokenModel?.expireAtDateTime else {
            return false
        }
        
        let sessionDateFormatter: DateFormatter = DateFormatter()
        sessionDateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss '+0000'"
        
        let now: String = "\(Date(timeIntervalSinceNow: 0))"
        
        let expireAtDate = sessionDateFormatter.date(from: expireDate)! as Date
        let nowDate = sessionDateFormatter.date(from: now)! as Date
        
        return (expireAtDate > nowDate)
    }
    
    // MARK: - Internal Methods
    
    /// Override User Access Token Session
    func overrideUserAccessToken(session: [String: Any]?) {
        
        guard var sessionData: [String: Any] = session else {
            return
        }
        
        for key in Array(sessionData.keys) {
            
            if (sessionData[key] is NSNull) {
                sessionData[key] = nil
            }
        }
        
        self.userAccessTokenModel = UserProfilesModel(withDict: sessionData)
        
        UserDefaults.standard.set(sessionData, forKey: USER_ACCESS_TOKEN_SESSION_KEY)
    }
    
    func setAccessTokenExpire() {
        
        let session: [String: Any]? = UserDefaults.standard.object(forKey: USER_ACCESS_TOKEN_SESSION_KEY) as? [String: Any]
        
        guard var sessionData: [String: Any] = session else {
            return
        }
        
        sessionData["expireAtDateTime"] = "2000-01-01 00:00:00 +0000"
        
        overrideUserAccessToken(session: sessionData)
    }
    
    // MARK: - Private Methods
    
    /// Reload User Access Token Session
    private func reloadUserAccessTokenSession() {
        
        if self.userAccessTokenModel != nil {
            return
        }
        
        let session: [String: Any]? = UserDefaults.standard.object(forKey: USER_ACCESS_TOKEN_SESSION_KEY) as? [String: Any]
        
        guard let sessionData: [String: Any] = session else {
            return
        }
        
        self.userAccessTokenModel = UserProfilesModel(withDict: sessionData)
    }
    
}
