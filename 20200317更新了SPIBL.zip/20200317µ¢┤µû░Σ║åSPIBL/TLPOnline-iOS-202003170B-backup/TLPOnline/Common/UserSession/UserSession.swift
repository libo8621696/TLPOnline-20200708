//
//  UserSession
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class UserSession: NSObject {
    
    // MARK: - Internal Property
    
    var userAccessTokenModel: UserProfilesModel?
    
    var takeoffAirportModels: [AirportModel]?
    var landingAirportModels: [AirportModel]?
    
    var takeoffCDLDatas: [Int]?
    var landingCDLDatas: [Int]?
    
    var runwayModels: [String: [RunwayModel]]?

    // MARK: - Private Property
    
    // MARK: - Internal Methods
    
    /// Create single class instance object
    private static let sharedInstance = UserSession()
    private override init() {
        super.init()
    }
    
    /// Create instance object
    class func CurrentSession() -> UserSession {
    
        return sharedInstance
    }
    
    /// remove user session
    func removeUserSession() {
        
        self.userAccessTokenModel = nil
        self.takeoffAirportModels = nil
        self.takeoffCDLDatas = nil
        self.landingCDLDatas = nil
        self.landingAirportModels = nil
        self.runwayModels = nil
        
        let defs: UserDefaults = UserDefaults.standard
        let dict: [String : Any] = defs.dictionaryRepresentation()
        
        for key in Array(dict.keys) {
            
            if key != APP_LANGUAGES_KEY &&
               key != APP_LANGUAGES_USER_KEY &&
               key != API_ROOT_URL_KEY &&
               key != USER_LOGIN_NAME_KEY {
                UserDefaults.standard.removeObject(forKey: key)
            }
        }
    }

}
