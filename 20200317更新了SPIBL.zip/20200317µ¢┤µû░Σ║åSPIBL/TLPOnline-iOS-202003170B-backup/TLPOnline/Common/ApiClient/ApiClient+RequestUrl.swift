//
//  ApiClient+RequestUrl.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation


// MARK: - Api URL Path


// MARK: - Private Property

private let API_VERSION_V1              = "/api"

// MARK: - Internal Property

// MARK: Authentication

let API_AUTH_LOGIN_URL_PATH             = API_VERSION_V1 + "/login"
let API_AUTH_LOGOUT_URL_PATH            = API_VERSION_V1 + "/logout"

let API_AUTH_PASSWORD_URL_PATH          = API_VERSION_V1 + "/password"

let API_AIRPORT_URL_PATH                = API_VERSION_V1 + "/airports"
let API_RUNWAY_URL_PATH                 = API_VERSION_V1 + "/airport"

let API_TAKEOFF_CALCULATE_URL_PATH      = API_VERSION_V1 + "/pes/tlp01"
let API_LANDING_CALCULATE_URL_PATH      = API_VERSION_V1 + "/pes/tlp05"
