//
//  ApiClient.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit


class ApiClient: NSObject {
    
    // MARK: - Internal Property
    
    /// Api Base URL Path

    var API_BASE_URL_PATH: String! {
        return Q_UserDefaultsObjectGet(API_ROOT_URL_KEY) as? String ?? API_ROOT_DEFAULT_URL
    }
    
    // MARK: - Private Property
    
    /// net request manager
    var manager: AFHTTPSessionManager = AFHTTPSessionManager()
    
    // MARK: - ApiClient Methods
    
    /// Create single class instance object
    private static let sharedInstance = ApiClient()
    private override init() {
        
        self.manager.responseSerializer.acceptableContentTypes = NSSet(objects: "application/json",
                                                                                "text/json",
                                                                                "text/javascript",
                                                                                "text/html") as? Set<String>
    }
    
    /**
     *  Create instance object
     *
     *  @return ApiClient instance
     */
    class func DefaultClient() -> ApiClient {
        
        let baseURL: URL? = URL(string: Q_UserDefaultsObjectGet(API_ROOT_URL_KEY) as? String ?? API_ROOT_DEFAULT_URL)
        ApiClient.sharedInstance.manager = AFHTTPSessionManager(baseURL: baseURL)
        return ApiClient.sharedInstance
    }
    
}
