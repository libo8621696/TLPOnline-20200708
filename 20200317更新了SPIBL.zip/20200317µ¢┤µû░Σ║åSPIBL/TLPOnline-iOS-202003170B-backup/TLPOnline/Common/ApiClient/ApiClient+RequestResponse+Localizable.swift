//
//  ApiClient+RequestResponse+Localizable.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation


// MARK: - Request Response Error Domain

extension RequestResponseErrorDomain {

    var localValue: String {

        switch self {

            case .networkLinkError:
                return Q_LocalizedString("RequestResponse.domain.networkLinkError")

            case .apiReceivedError:
                return Q_LocalizedString("RequestResponse.domain.apiReceivedError")
        }
    }
}

// MARK: - Request Response Code

extension RequestResponseCode {

    var localValue: String {

        switch self {
            
            case .requestTimedOut:
                return Q_LocalizedString("RequestResponse.code.requestTimedOut")

            case .serverHostnameCouldNotBeFound:
                return Q_LocalizedString("RequestResponse.code.serverHostnameCouldNotBeFound")
            
            case .networkLinkSuccess:
                return Q_LocalizedString("RequestResponse.code.networkLinkSuccess")

            case .networkLinkFailure:
                return Q_LocalizedString("RequestResponse.code.networkLinkFailure")

            case .networkLinkLost:
                return Q_LocalizedString("RequestResponse.code.networkLinkLost")
            
            case .successed:
                return Q_LocalizedString("RequestResponse.code.successed")

            case .responseObjectIsEmpty:
                return Q_LocalizedString("RequestResponse.code.loadDataFailure")

//            case .unauthorized:
//                return Q_LocalizedString("RequestResponse.code.accessTokenExpired")
            
            case .unauthorized:
                return Q_LocalizedString("RequestResponse.code.userNameOrPasswordIsInvalid")


            case .pageUnfound:
                return Q_LocalizedString("RequestResponse.code.pageUnfound")
            
            case .serverError:
                return Q_LocalizedString("RequestResponse.code.serverError")

            case .invalidRequestParam:
                return Q_LocalizedString("RequestResponse.code.invalidRequestParam")

            case .userNameOrPasswordIsInvalid:
                return Q_LocalizedString("RequestResponse.code.userNameOrPasswordIsInvalid")

            case .userNotExist:
                return Q_LocalizedString("RequestResponse.code.userNotExist")

            case .loginFailure:
                return Q_LocalizedString("RequestResponse.code.loginFailure")
            
            case .logoutFailure:
                return Q_LocalizedString("RequestResponse.code.logoutFailure")

            case .verifyFailure:
                return Q_LocalizedString("RequestResponse.code.verifyFailure")
            
            case .loadDataFailure:
                return Q_LocalizedString("RequestResponse.code.loadDataFailure")
            
//            case .uuidCountUpToLimit:
//                return Q_LocalizedString("RequestResponse.code.uuidCountUpToLimit")
//            
//            case .uuidCompanyNotMatch:
//                return Q_LocalizedString("RequestResponse.code.uuidCompanyNotMatch")
//            
//            case .invalidUuid:
//                return Q_LocalizedString("RequestResponse.code.invalidUuid")
        }
    }
}
