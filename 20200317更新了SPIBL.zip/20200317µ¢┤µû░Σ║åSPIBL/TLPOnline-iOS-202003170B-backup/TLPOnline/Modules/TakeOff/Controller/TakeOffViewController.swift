//
//  TakeOffViewController.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class TakeOffViewController: PublicBaseViewController, UITextFieldDelegate,
                             QDropDownMenuDelegate, QDeviceOrientationDelegate,
                             QAlertListViewDelegate {
    
    // MARK: - Internal Property
    
    
    // MARK: - IBOutlet Property
    
    @IBOutlet weak var airportPromptLabel: UILabel!
    @IBOutlet weak var oatPromptLabel: UILabel!
    @IBOutlet weak var windPromptLabel: UILabel!
    @IBOutlet weak var rwConditionPromptLabel: UILabel!
    @IBOutlet weak var runwayPromptLabel: UILabel!
    @IBOutlet weak var qnhPromptLabel: UILabel!
    @IBOutlet weak var takeoffWPromptLabel: UILabel!
    @IBOutlet weak var antiIcePromptLabel: UILabel!
    
    @IBOutlet weak var oatTextField: UITextField!
    @IBOutlet weak var windTextField: UITextField!
    @IBOutlet weak var qnhTextField: UITextField!
    @IBOutlet weak var takeoffWTextField: UITextField!
    
    @IBOutlet weak var airportButton: UIButton!
    @IBOutlet weak var rwConditionButton: UIButton!
    @IBOutlet weak var runwayButton: UIButton!
    @IBOutlet weak var antiIceButton: UIButton!
    
    @IBOutlet weak var calculateButton: UIButton!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var cdlItemsButton: UIButton!
    
    @IBOutlet weak var v1Label: UILabel!
    @IBOutlet weak var vrLabel: UILabel!
    @IBOutlet weak var v2Label: UILabel!
    @IBOutlet weak var maxAccHLabel: UILabel!
    @IBOutlet weak var minAccHLabel: UILabel!
    @IBOutlet weak var mTOWLabel: UILabel!
    @IBOutlet weak var limitLabel: UILabel!
    
    // MARK: - Private Property
    
    private var deviceOrientationMotion: QDeviceOrientation!
    private var deviceLastDirection: QDeviceOrientationState?
    
    private var airportDropDownMenu: QDropDownMenu = QDropDownMenu()
    private var rwConditionDropDownMenu: QDropDownMenu = QDropDownMenu()
    private var runwayDropDownMenu: QDropDownMenu = QDropDownMenu()
    private var antiIceDropDownMenu: QDropDownMenu = QDropDownMenu()
    
    // Data
    private var resultShowingDatas: CalculateResultModel!
    
    private var netState: Bool = true

    private var airportDatas: [String] = []
    private var runwayDatas: [String] = []

    private let rwConditionDatas: [String] = [
        Q_LocalizedString("Takeoff.rwCondition.Dry"),
        Q_LocalizedString("Takeoff.rwCondition.Wet"),
        Q_LocalizedString("Takeoff.rwCondition.6.3mmWater"),
        Q_LocalizedString("Takeoff.rwCondition.12.7mmWate"),
        Q_LocalizedString("Takeoff.rwCondition.6.3mmSlush"),
        Q_LocalizedString("Takeoff.rwCondition.12.7mmSlush"),
        Q_LocalizedString("Takeoff.rwCondition.5mmWetSnow"),
        Q_LocalizedString("Takeoff.rwCondition.12.7mmWetSnow"),
        Q_LocalizedString("Takeoff.rwCondition.10mmDrySnow"),
        Q_LocalizedString("Takeoff.rwCondition.12.7mmDrySnow"),
        Q_LocalizedString("Takeoff.rwCondition.CompactSnow"),
        Q_LocalizedString("Takeoff.rwCondition.Ice")
    ]
    
    private let antiIceDatas: [String] = [
        Q_LocalizedString("Takeoff.antiIce.ALLOFF"),
        Q_LocalizedString("Takeoff.antiIce.Engineonly"),
        Q_LocalizedString("Takeoff.antiIce.ALLON")
    ]

    private let limitDatas: [String] = [
        Q_LocalizedString("Takeoff.limit.1stSegment"),         // 1
        Q_LocalizedString("Takeoff.limit.2ndSegment"),         // 2
        Q_LocalizedString("Takeoff.limit.RunwayLength"),       // 3
        Q_LocalizedString("Takeoff.limit.Obstacles"),          // 4
        Q_LocalizedString("Takeoff.limit.TireSpeed"),          // 5
        Q_LocalizedString("Takeoff.limit.BrakeEnergy"),        // 6
        Q_LocalizedString("Takeoff.limit.MaxWeight"),          // 7
        Q_LocalizedString("Takeoff.limit.FinalTake")           // 8
    ]

    // View
    
    var coverView: UIButton!
    var alertListView: QAlertListView!
    
    private enum TargetViewTag: Int {
        case airport = 0
        case oat = 1
        case wind = 2
        case rwCondition = 3
        case runway = 4
        case qnh = 5
        case takeoffW = 6
        case antiIce = 7
    }
    
    private var textFields: [UITextField] {
        return [
            self.oatTextField,
            self.windTextField,
            self.qnhTextField,
            self.takeoffWTextField
        ]
    }
    
    private var dropDownButtons: [UIButton] {
        return [
            self.airportButton,
            self.rwConditionButton,
            self.runwayButton,
            self.antiIceButton
        ]
    }
    
    private var dropDownMenus: [QDropDownMenu] {
        return [
            airportDropDownMenu,
            rwConditionDropDownMenu,
            runwayDropDownMenu,
            antiIceDropDownMenu
        ]
    }
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Init View
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.initNavigationBar()
        self.initTextField()
        self.initialQDropDownMenu()
        self.initOrientationStatus()
        self.initShowingDatas()
        self.initResultDatas()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.setNavigationBarLogo()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.hideQAlertListView()
        self.stopDeviceOrientationMonitor()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    // MARK: - Showing Datas
    
    func initShowingDatas() {
        
        initNetWorkMonitoring(with: #selector(loadAirportDatas))
    }
    
    // MARK: Airport
    
    @objc func loadAirportDatas() {
        
        if UserSession.CurrentSession().takeoffAirportModels != nil {

            self.initialAirportShowingDatas(UserSession.CurrentSession().takeoffAirportModels!)
            return
        }
        
        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Public.loading"), true)
        
        PublicAirportDataSourceService()
            .loadAirports(success: { (result: [AirportModel]) in

                UserSession.CurrentSession().takeoffAirportModels = result
                self.loadAirportSuccessAction(result)
                
            }, failure: { (error: Error) in

                UserSession.CurrentSession().takeoffAirportModels = nil
                self.loadAirportFailureAction(error)
            })
    }
    
    func loadAirportSuccessAction(_ result: [AirportModel]) {
        
        self.hideHudMain(hud: self.hud)

        self.setAirportShowingDatas(result)
    }
    
    func loadAirportFailureAction(_ error: Error) {

        self.hideHudMain(hud: self.hud)
        
        self.airportDatas = []
        
        switch (error as NSError).code {

            case RequestResponseCode.loadDataFailure.rawValue,
                 RequestResponseCode.responseObjectIsEmpty.rawValue:
                QF_AlertShow_Note_Main(self, Q_LocalizedString("RequestResponse.code.loadAirportDataFailure"))
            
            default:
                RequestResponseErrorAlert(error: error,
                                         target: self,
                                   defaultBlock: {
                                       QF_AlertShow_Note_Main(self, RequestResponseCode.loadDataFailure.localValue)
                                   })
        }
    }
    
    func initialAirportShowingDatas(_ airportModels: [AirportModel]) {
        
        self.airportDatas.removeAll()
        
        airportModels.forEach { (airport: AirportModel) in
            if airport.ICAOCode != nil {
                self.airportDatas.append(airport.ICAOCode ?? "")
            }
        }
    }
    
    func setAirportShowingDatas(_ airportModels: [AirportModel]) {
        
        self.initialAirportShowingDatas(airportModels)
        
        if self.airportDatas.count > 0 {
            self.airportButton.setTitle(self.airportDatas[0], for: .normal)
            self.runwayButton.setTitle(nil, for: .normal)
            self.runwayButton.titleLabel?.text = nil
            self.runwayPromptLabel.text = ""
            self.loadRunwayDatas(withAiportCode: self.airportButton.titleLabel?.text ?? "")
        }
    }
    
    // MARK: Runway
    
    @objc func loadRunwayDatas(withAiportCode airportCode: String) {
        
        if UserSession.CurrentSession().runwayModels != nil &&
           UserSession.CurrentSession().runwayModels?[airportCode] != nil {

            self.setRunwayShowingDatas(UserSession.CurrentSession().runwayModels![airportCode]!)
            return
        }
        
        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Public.loading"), true)
        
        PublicAirportDataSourceService()
        .loadRunway(withAirportCode: airportCode,
            success: { (result: [RunwayModel]) in
                
                if UserSession.CurrentSession().runwayModels == nil {
                    UserSession.CurrentSession().runwayModels = [:]
                }
                UserSession.CurrentSession().runwayModels![airportCode] = result
                self.loadRunwaySuccessAction(result)
                
            }, failure: { (error: Error) in
                
                if UserSession.CurrentSession().runwayModels != nil {
                    UserSession.CurrentSession().runwayModels![airportCode] = nil
                }
                self.loadRunwayFailureAction(error)
            })
    }
    
    func loadRunwaySuccessAction(_ result: [RunwayModel]) {
        
        self.hideHudMain(hud: self.hud)

        self.setRunwayShowingDatas(result)
    }
    
    func loadRunwayFailureAction(_ error: Error) {

        self.hideHudMain(hud: self.hud)
        
        self.runwayDatas = []
        
        switch (error as NSError).code {
            
            case RequestResponseCode.loadDataFailure.rawValue,
                 RequestResponseCode.responseObjectIsEmpty.rawValue:
                QF_AlertShow_Note_Main(self, Q_LocalizedString("RequestResponse.code.loadRunwayDataFailure"))
            
            default:
                RequestResponseErrorAlert(error: error,
                                         target: self,
                                   defaultBlock: {
                                       QF_AlertShow_Note_Main(self, RequestResponseCode.loadDataFailure.localValue)
                                   })
        }
    }
    
    func setRunwayShowingDatas(_ airportModels: [RunwayModel]) {
        
        self.runwayDatas.removeAll()
        
        airportModels.forEach { (airport: RunwayModel) in
            if airport.ICAOCode != nil {
                self.runwayDatas.append(airport.Designation ?? "")
            }
        }
        
        if self.runwayDatas.count > 0 {
            self.runwayButton.setTitle(self.runwayDatas[0], for: .normal)
            self.runwayPromptLabel.text = ""
        }
    }
    
    // MARK: - Result Datas
    
    func initResultDatas() {
        
        self.setResultDatas()
    }
    
    func reSetResultDatas() {
        
        self.setResultDatas()
    }
    
    func setResultDatas() {
        
        guard let result = self.resultShowingDatas else {

            self.clearResultDatas()
            return
        }
        
        self.v1Label.text = (result.V1CAS != nil) ? "\(result.V1CAS!) Kt" : ""
        self.vrLabel.text = (result.VRCAS != nil) ? "\(result.VRCAS!) Kt" : ""
        self.v2Label.text = (result.V2CAS != nil) ? "\(result.V2CAS!) Kt" : ""
        self.maxAccHLabel.text = (result.MaxAccH != nil) ? "\(result.MaxAccH!) feet" : ""
        self.minAccHLabel.text = (result.MinAccH != nil) ? "\(result.MinAccH!) feet" : ""
        self.mTOWLabel.text = (result.MTOW != nil) ? "\(result.MTOW!) kg" : ""
        self.limitLabel.text = (result.LimitCode != nil) ? "\(limitDatas[result.LimitCode!.intValue - 1])" : ""
    }
    
    func clearResultDatas() {
        
        self.resultShowingDatas = nil
        self.v1Label.text = ""
        self.vrLabel.text = ""
        self.v2Label.text = ""
        self.maxAccHLabel.text = ""
        self.minAccHLabel.text = ""
        self.mTOWLabel.text = ""
        self.limitLabel.text = ""
    }
    
    // MARK: - User Event Handle
    
    // MARK: Click
    
    @IBAction func airportButtonDidClick(_ sender: UIButton) {
        
        self.hideAllDropDownMenu()
        self.textFields.forEach { (tf: UITextField) in
            tf.resignFirstResponder()
        }
        
        self.showQAlertListView()
        
        //self.airportDropDownMenu.delegate = self
        //self.hideOtherDropDownMenu(dropDownMenu: airportDropDownMenu)
        //self.showDropDownMenu(dropDownMenu: self.airportDropDownMenu,
        //                      titles: self.airportDatas,
        //                      button: sender,
        //                      direction: "down")
    }
    
    @IBAction func rwConditionButtonDidClick(_ sender: UIButton) {
        
        self.rwConditionDropDownMenu.delegate = self
        self.hideOtherDropDownMenu(dropDownMenu: rwConditionDropDownMenu)
        self.showDropDownMenu(dropDownMenu: self.rwConditionDropDownMenu,
                              titles: self.rwConditionDatas,
                              button: sender,
                              direction: "down")
    }
    
    @IBAction func runwayButtonDidClick(_ sender: UIButton) {
        
        self.runwayDropDownMenu.delegate = self
        self.hideOtherDropDownMenu(dropDownMenu: runwayDropDownMenu)
        self.showDropDownMenu(dropDownMenu: self.runwayDropDownMenu,
                              titles: self.runwayDatas,
                              button: sender,
                              direction: "down")
    }
    
    @IBAction func antiIceButtonDidClick(_ sender: UIButton) {
        
        self.antiIceDropDownMenu.delegate = self
        self.hideOtherDropDownMenu(dropDownMenu: antiIceDropDownMenu)
        self.showDropDownMenu(dropDownMenu: self.antiIceDropDownMenu,
                              titles: self.antiIceDatas,
                              button: sender,
                              direction: "down")
    }
    
    @IBAction func calculateButtonDidClick(_ sender: UIButton) {
        
        if !AirportIsValid(self.airportButton.titleLabel?.text) ||
            !RunwayIsValid(self.runwayButton.titleLabel?.text) ||
            !OatIsValid(self.oatTextField.text != "" ? self.oatTextField.text : self.oatTextField.placeholder) ||
            !QnhIsValid(self.qnhTextField.text != "" ? self.qnhTextField.text : self.qnhTextField.placeholder) ||
            !WindIsValid(self.windTextField.text != "" ? self.windTextField.text : self.windTextField.placeholder) ||
            !TakeoffWIsValid(self.takeoffWTextField.text != "" ? self.takeoffWTextField.text : self.takeoffWTextField.placeholder) ||
            !RwConditionIsValid(self.rwConditionButton.titleLabel?.text) ||
            !AntiIceIsValid(self.antiIceButton.titleLabel?.text) {
            
            if !AirportIsValid(self.airportButton.titleLabel?.text) {
                self.airportPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.airport")
            }
            if !RunwayIsValid(self.runwayButton.titleLabel?.text) {
                self.runwayPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.runway")
            }
            
            QF_AlertShow_Note_Main(self, RequestResponseCode.invalidRequestParam.localValue)
            
            return
        }
        
        self.calculate()
    }
    
    @IBAction func clearButtonDidClick(_ sender: UIButton) {
        
        self.clear()
    }
    
    @IBAction func cdlItemsButtonDidClick(_ sender: UIButton) {
        
        self.pushToFrmCDLVC()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.hideAllDropDownMenu()
    }
    
    // MARK: Editing Changed
    
    @objc func textFieldDidChanged(textField: UITextField) {

        if textField.text != "" {
            setPromptMsg(withTag: textField.tag)
        }
    }
    
    // MARK: Calculate
    
    func calculate() {
        
        self.clearResultDatas()
        
        let airportValue: String = self.airportButton.titleLabel?.text ?? ""
        let runwayValue: String = self.runwayButton.titleLabel?.text ?? ""
        let oatValue = Double((self.oatTextField.text != "" ? self.oatTextField.text : self.oatTextField.placeholder)!)
        let qnhValue = Double((self.qnhTextField.text != "" ? self.qnhTextField.text : self.qnhTextField.placeholder)!)
        let windValue = Double((self.windTextField.text != "" ? self.windTextField.text : self.windTextField.placeholder)!)
        let rwConditionValue = self.rwConditionDatas.index(of: self.rwConditionButton.titleLabel?.text ?? "")
        let takeoffWValue = Double((self.takeoffWTextField.text != "" ? self.takeoffWTextField.text : self.takeoffWTextField.placeholder)!)
        let antiIceValue = self.antiIceDatas.index(of: self.antiIceButton.titleLabel?.text ?? "")
        
        let calculate: CalculateParamModel = CalculateParamModel()
        calculate.airport = airportValue
        calculate.runway = runwayValue
        calculate.oat = NSNumber(value: oatValue!)
        calculate.qnh = NSNumber(value: qnhValue!)
        calculate.wind = NSNumber(value: windValue!)
        calculate.rwCondition = NSNumber(value: rwConditionValue!)
        calculate.takeoffW = NSNumber(value: takeoffWValue!)
        calculate.antiIce = NSNumber(value: antiIceValue!)
        
        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Public.calculating"), true)

        PublicCalculateDataSourceService()
            .calculate(withType: .takeoff,
                       params: calculate,
            success: { (result: CalculateResultModel) in
                
                self.calculateSuccessAction(result)

            }) { (error: Error) in
                
                self.calculateFailureAction(error)
            }
    }
    
    func calculateSuccessAction(_ result: CalculateResultModel) {

        self.hideHudMain(hud: self.hud)

        self.resultShowingDatas = result
        self.setResultDatas()
    }

    func calculateFailureAction(_ error: Error) {

        self.hideHudMain(hud: self.hud)

        self.resultShowingDatas = nil
        
        switch (error as NSError).code {
            
            case RequestResponseCode.loadDataFailure.rawValue:
                QF_AlertShow_Note_Main(self, Q_LocalizedString("RequestResponse.code.loadCalculateDataFailure"))
            
            default:
                RequestResponseErrorAlert(error: error,
                                         target: self,
                                   defaultBlock: nil)
        }
    }
    
    // MARK: Clear
    
    func clear() {
        
        self.resultShowingDatas = nil
        self.reSetResultDatas()
    }
    
    // MARK: - Net Monitoring
    
    // MARK: Init
    
    func initNetWorkMonitoring(with selector: Selector) {
        
        QM_AFN_NET_MONITOR_NOTIFICATION_OBSERVER_ADD(self, #selector(netStatesDidChanged(n:)))
        
        if QM_AFN_NET_IS_START_MONITORING() == true {
            self.perform(selector)
        } else {
            self.perform(selector, with: nil, afterDelay: 0.5)
        }
    }
    
    // MARK: Event Handle
    
    @objc func netStatesDidChanged(n: Notification) {
        
        if QM_AFN_NET_IS_REACHABLE() == true {
            if self.netState == false {
                self.netState = true
                
                QF_AlertShow_Note_Main(self, RequestResponseCode.networkLinkSuccess.localValue)
            }
        } else {
            if self.netState == true {
                self.netState = false
                
                QF_AlertShow_Warning_Main(self, RequestResponseCode.networkLinkFailure.localValue)
            }
        }
    }
    
    // MARK: - Navigation Bar
    
    func initNavigationBar() {
        
        Q_NavigationBarTitleSet(self, Q_LocalizedString("Takeoff.title"))
    }
    
    func setNavigationBarLogo() {
        
        let image = UIImage(named: "icon-logo-r")
        Q_NavigationBarLeftImageButtonSet_image(self, image, nil)
        Q_NavigationBarLeftBarButtonItem(self)?.isEnabled = false
    }
    
    // MARK: - Prompt Msg

    func setPromptMsg(withTag tag: Int) {

        switch tag {

            case TargetViewTag.oat.rawValue:
                if OatIsValid(self.oatTextField.text) {
                    self.oatPromptLabel.text = ""
                } else {
                    self.oatPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.oat")
                }
            
            case TargetViewTag.qnh.rawValue:
                if QnhIsValid(self.qnhTextField.text) {
                    self.qnhPromptLabel.text = ""
                } else {
                    self.qnhPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.qnh")
                }
            
            case TargetViewTag.wind.rawValue:
                if WindIsValid(self.windTextField.text) {
                    self.windPromptLabel.text = ""
                } else {
                    self.windPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.wind")
                }
            
            case TargetViewTag.takeoffW.rawValue:
                if TakeoffWIsValid(self.takeoffWTextField.text) {
                    self.takeoffWPromptLabel.text = ""
                } else {
                    self.takeoffWPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.takeoffW")
                }

            default:
                break
        }
    }

    // MARK: - Text Field

    func initTextField() {

        for tf in self.textFields {

            tf.addTarget( self,
                  action: #selector(textFieldDidChanged(textField:)),
                     for: .editingChanged)
        }
    }

    // MARK: UITextFieldDelegate

    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if textField.text != "" {
            setPromptMsg(withTag: textField.tag)
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        switch textField.tag {
            case self.oatTextField.tag:
                self.qnhTextField.becomeFirstResponder()
            case self.qnhTextField.tag:
                self.windTextField.becomeFirstResponder()
            case self.windTextField.tag:
                self.takeoffWTextField.becomeFirstResponder()
            default:
                self.takeoffWTextField.resignFirstResponder()
        }
        
        return true
    }
    
    // MARK: - QDropDownMenu
    
    func initialQDropDownMenu() {
        
        self.rwConditionButton.setTitle(self.rwConditionDatas[0], for: .normal)
        self.antiIceButton.setTitle(self.antiIceDatas[0], for: .normal)
        
        for menu: QDropDownMenu in self.dropDownMenus {
            menu.tag = 1000
        }
    }
    
    func showDropDownMenu(dropDownMenu: QDropDownMenu,
                           titles: [String],
                           button: UIButton,
                           direction: String) {

        let frame: CGRect = button.frame
        let btnFrame: CGRect = CGRect(x: frame.origin.x,
                                      y: frame.origin.y + 70,
                                      width: frame.size.width,
                                      height: frame.size.height)
        if dropDownMenu.tag == 1000 {
            dropDownMenu.show(button,
                              withButtonFrame: btnFrame,
                              arrayOfTitle: titles,
                              arrayOfImage: nil,
                              animationDirection: direction)
            self.view.addSubview(dropDownMenu)
            dropDownMenu.tag = 2000
        } else {
            dropDownMenu.hide(withBtnFrame: btnFrame)
            dropDownMenu.tag = 1000
        }
    }
    
    func hideOtherDropDownMenu(dropDownMenu: QDropDownMenu) {
        
        for menu: QDropDownMenu in self.dropDownMenus {
            if menu != dropDownMenu {
                let index: Int = dropDownMenus.index(of: menu)!
                let frame: CGRect = self.dropDownButtons[index].frame
                let btnFrame: CGRect = CGRect(x: frame.origin.x,
                                              y: frame.origin.y + 70,
                                              width: frame.size.width,
                                              height: frame.size.height)
                menu.hide(withBtnFrame: btnFrame)
                menu.tag = 1000
            }
        }
    }
    
    func hideAllDropDownMenu() {
        
        for menu: QDropDownMenu in self.dropDownMenus {
            let index: Int = dropDownMenus.index(of: menu)!
            let frame: CGRect = self.dropDownButtons[index].frame
            let btnFrame: CGRect = CGRect(x: frame.origin.x,
                                          y: frame.origin.y + 70,
                                          width: frame.size.width,
                                          height: frame.size.height)
            menu.hide(withBtnFrame: btnFrame)
            menu.tag = 1000
        }
    }
    
    // MARK: QDropDownMenuDelegate

    func setDropDown(_ sender: QDropDownMenu!, title: String!) {
        
        sender.tag = 1000
        
        if sender == self.airportDropDownMenu {
            self.airportPromptLabel.text = ""
            self.runwayButton.setTitle(nil, for: .normal)
            self.runwayButton.titleLabel?.text = nil
            self.runwayPromptLabel.text = ""
            self.loadRunwayDatas(withAiportCode: title)
        }
        if sender == self.runwayDropDownMenu {
            self.runwayPromptLabel.text = ""
        }
    }
    
    // MARK: - QAlertListView
    
    func showQAlertListView() {
        
        let width = self.view.bounds.size.width
        let height = self.view.bounds.size.height
        let h = (height > width ? width : height) * 0.7
        let w = h / 3.0 * 2.5
        
        self.coverView = UIButton(frame: UIScreen.main.bounds)
        self.coverView.backgroundColor = UIColor.black
        self.coverView.alpha = 0.2
        self.coverView.addTarget(self, action: #selector(coverViewDidClick), for: .touchUpInside)
        
        self.view.addSubview(self.coverView)
        
        self.alertListView = QAlertListView(frame: CGRect(x: 0, y: 0, width: w, height: h))
        self.alertListView.titleLabel.text = Q_LocalizedString("Pop.choose.airport")
        self.alertListView.delegate = self
        self.alertListView.center = self.view.center
        self.view.addSubview(self.alertListView)
        
        var airports: [[String: String]] = []
        if UserSession.CurrentSession().takeoffAirportModels != nil {
            UserSession.CurrentSession().takeoffAirportModels!.forEach { (airport: AirportModel) in
                if airport.ICAOCode != nil {
                    airports.append([
                        "AirportName": airport.AirportName ?? "",
                        "CityName": airport.CityName ?? "",
                        "CountryName": airport.CountryName ?? "",
                        "ICAOCode": airport.ICAOCode ?? "",
                        "IATACode": airport.IATACode ?? ""
                    ])
                }
            }
        }
        
        self.alertListView.datas = airports
    }
    
    func hideQAlertListView() {
        
        if self.coverView != nil {
            self.coverView.removeFromSuperview()
        }
        if self.alertListView != nil {
            self.alertListView.removeFromSuperview()
        }
    }
    
    @objc func coverViewDidClick() {
        
        self.hideQAlertListView()
    }
    
    // MARK: QAlertListViewDelegate
    
    func didSelectRow(atTitle title: String!) {
        
        self.hideQAlertListView()
        
        self.airportPromptLabel.text = ""
        self.airportButton.setTitle(title, for: .normal)
        self.runwayButton.setTitle(nil, for: .normal)
        self.runwayButton.titleLabel?.text = nil
        self.runwayPromptLabel.text = ""
        self.loadRunwayDatas(withAiportCode: title)
    }
    
    func cancelButtonDidClick() {
        
        self.hideQAlertListView()
    }
    
    // MARK: - QOrientationStatus
    
    func initOrientationStatus() {
        
        startDeviceOrientationMonitor()
        self.deviceLastDirection = Q_DeviceOrientation()
    }
    
    func startDeviceOrientationMonitor() {
        
        self.deviceOrientationMotion = QDeviceOrientation(delegate: self,
                                                          defaultDirection: Q_DeviceInterfaceOrientation())
        self.deviceOrientationMotion.q_startMonitor()
    }

    func stopDeviceOrientationMonitor() {
        
        self.deviceOrientationMotion.q_stopMonitor()
    }
    
    func q_devicenOrientationDidChanged() {
        
        let direction: QDeviceOrientationState = Q_DeviceOrientation()
        
        if Q_DeviceOrientationIsFace(direction)  ||
           self.deviceLastDirection == direction {
            return
        }
        
        self.deviceLastDirection = direction
        
        self.hideAllDropDownMenu()
        self.hideQAlertListView()
    }
    
    // MARK: - Navigation
    
    func pushToFrmCDLVC() {
        
        QF_PresentViewControllerWithSegueIdentifier(self, .frmCDL)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
       
        let vc: UIViewController = segue.destination
        
        switch vc {
            
            case is FrmCDLViewController:
                let v: FrmCDLViewController = vc as! FrmCDLViewController
                v.calculateType = .takeoff
            
            default:
                break
        }
    }
    
}
