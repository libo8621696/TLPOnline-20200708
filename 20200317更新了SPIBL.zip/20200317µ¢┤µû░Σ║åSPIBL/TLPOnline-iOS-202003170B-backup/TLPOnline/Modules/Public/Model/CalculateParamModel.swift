//
//  CalculateParamModel.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/18.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class CalculateParamModel: NSObject {
    
    // MARK: - Internal Property
    
    @objc var airport     : String?
    @objc var runway      : String?
    @objc var oat         : NSNumber?
    @objc var qnh         : NSNumber?
    @objc var wind        : NSNumber?
    @objc var rwCondition : NSNumber?
    
    @objc var takeoffW    : NSNumber?
    @objc var antiIce     : NSNumber?
    
    @objc var ldgConf     : NSNumber?
    @objc var brakeMode   : NSNumber?
    @objc var reversers   : NSNumber?

    // MARK: - Internal Methods
    
    init(withDict dict:[String: Any]) {
        super.init()
        setValuesForKeys(dict)
    }
    
    // MARK: - Private Methods
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
    }
    
    override func value(forUndefinedKey key: String) -> Any? {
        return nil
    }
    
    required override init() {
        super.init()
    }
    
}
