//
//  RunwayModel.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/17.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class RunwayModel: NSObject {
    
    // MARK: - Internal Property
    
    @objc var ICAOCode    : String?
    @objc var Designation : String?
    
    // MARK: - Internal Methods
    
    init(withDict dict:[String: Any]) {
        super.init()
        setValuesForKeys(dict)
    }
    
    // MARK: - Private Methods
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
    }
    
    override func value(forUndefinedKey key: String) -> Any? {
        return nil
    }
    
    required override init() {
        super.init()
    }
    
}
