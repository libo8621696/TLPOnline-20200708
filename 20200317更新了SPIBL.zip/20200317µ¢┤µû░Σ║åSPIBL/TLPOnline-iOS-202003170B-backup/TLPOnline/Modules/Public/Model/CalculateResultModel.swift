//
//  CalculateResultModel.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/18.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class CalculateResultModel: NSObject {
    
    // MARK: - Internal Property
    
    @objc var V1CAS     : NSNumber?
    @objc var VRCAS     : NSNumber?
    @objc var V2CAS     : NSNumber?
    @objc var MaxAccH   : NSNumber?
    @objc var MinAccH   : NSNumber?
    @objc var MTOW      : NSNumber?
    @objc var LimitCode : NSNumber?
    
    @objc var ALD       : NSNumber?
    @objc var RLD       : NSNumber?
    @objc var MLW       : NSNumber?
    @objc var VApp      : NSNumber?
    
    // MARK: - Internal Methods
    
    init(withDict dict:[String: Any]) {
        super.init()
        setValuesForKeys(dict)
    }
    
    // MARK: - Private Methods
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
    }
    
    override func value(forUndefinedKey key: String) -> Any? {
        return nil
    }
    
    required override init() {
        super.init()
    }
    
}
