//
//  AirportModel.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/17.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class AirportModel: NSObject {
    
    // MARK: - Internal Property
    
    @objc var AirportName : String?
    @objc var CityName    : String?
    @objc var CountryName : String?
    @objc var ICAOCode    : String?
    @objc var IATACode    : String?
    
          var runways     : [RunwayModel]?

    // MARK: - Internal Methods
    
    init(withDict dict:[String: Any]) {
        super.init()
        setValuesForKeys(dict)
    }
    
    // MARK: - Private Methods
    
    override func setValue(_ value: Any?, forUndefinedKey key: String) {
        
    }
    
    override func value(forUndefinedKey key: String) -> Any? {
        return nil
    }
    
    required override init() {
        super.init()
    }
    
}
