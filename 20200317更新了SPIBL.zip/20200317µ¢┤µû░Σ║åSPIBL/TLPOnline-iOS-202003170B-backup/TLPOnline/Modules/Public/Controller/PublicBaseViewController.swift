//
//  PublicBaseViewController.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class PublicBaseViewController: UIViewController {
    
    // MARK: - Internal Property
    
    var hud: MBProgressHUD? {
        willSet {
            if self.hud != nil {
                QM_MB_HUD_HIDE(self.hud)
                self.hud = nil
            }
        }
    }
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // MARK: - Init View
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        setNavigationBarStyle()
        setNavigationItemSubBackButton()
        
        setTabBar()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        clearProgressHud(progressHud: &self.hud)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
    }
    
    // MARK: - Navigation Bar

    func setNavigationBarStyle() {

        Q_NavigationBarStyleSet(self, false, "nav_bg_blue", Q_WhiteColor())
    }

    func setNavigationItemSubBackButton() {

        Q_NavigationItemSubBackButtonSet(self, Q_LocalizedString("Public.navItemBackButtonTitle.back"))
    }

    // MARK: - Tab Bar

    func setTabBar() {

        Q_TabBarSet(self, COLOR_MAIN, nil, nil)
    }

    // MARK: - Hud

    func clearProgressHud(progressHud: inout MBProgressHUD?) {

        if progressHud != nil {
            QM_MB_HUD_HIDE(progressHud)
            progressHud = nil
        }
    }

    func hudIsShowing() -> Bool {

        if self.hud != nil {
            return true
        }
        return false
    }

    func showActionResult(toHud progressHud: MBProgressHUD?, withMessage message: String?) {

        if progressHud != nil && message != nil {

            Q_Dispatch_Async_Main {
                progressHud!.label.text = message!
                progressHud!.mode = .determinate
                progressHud!.progress = 1.0
            }
        }
    }

    func hideHudMain(hud progressHud: MBProgressHUD?) {

        Q_Dispatch_Async_Main {
            QM_MB_HUD_HIDE(self.hud)
            self.hud = nil
        }
    }

    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        clearProgressHud(progressHud: &self.hud)
    }

}
