//
//  AppMainViewController.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit


var IS_ENABLE_FULL_SCREEN_AUTO_ROTATE: Bool                      = true
var SUPPORTED_INTERFACE_ORIENTATIONS: UIInterfaceOrientationMask = .all

class AppMainViewController: UINavigationController {
    
    // MARK: - init
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - UINavigationController 支持屏幕旋转
    
    override var shouldAutorotate: Bool {
        if Q_DeviceIsiPad() {
            if IS_ENABLE_FULL_SCREEN_AUTO_ROTATE == true {
                return true
            } else {
                return false
            }
        }
        return false
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return SUPPORTED_INTERFACE_ORIENTATIONS
    }
    
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        return .portrait
    }
    
}
