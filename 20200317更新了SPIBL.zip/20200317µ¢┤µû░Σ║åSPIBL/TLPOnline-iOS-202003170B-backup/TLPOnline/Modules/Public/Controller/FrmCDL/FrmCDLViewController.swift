//
//  FrmCDLViewController.swift
//  TLPOnline
//
//  Created by Qian Chia on 2020/3/2.
//  Copyright © 2020 COMAC. All rights reserved.
//

import UIKit

class FrmCDLViewController: PublicBaseViewController, UIGestureRecognizerDelegate,
                            QDropDownMenuDelegate, QDeviceOrientationDelegate {
    
    // MARK: - Internal Property
    
    var calculateType: CalculateType = .none
    
    // MARK: - IBOutlet Property
    
    @IBOutlet weak var frmCDL1Button: UIButton!
    @IBOutlet weak var frmCDL2Button: UIButton!
    @IBOutlet weak var frmCDL4Button: UIButton!
    @IBOutlet weak var frmCDL5Button: UIButton!
    @IBOutlet weak var frmCDL7Button: UIButton!
    @IBOutlet weak var frmCDL8Button: UIButton!
    @IBOutlet weak var frmCDL9Button: UIButton!
    @IBOutlet weak var frmCDL10Button: UIButton!
    @IBOutlet weak var frmCDL11Button: UIButton!
    @IBOutlet weak var frmCDL12Button: UIButton!
    @IBOutlet weak var frmCDL17Button: UIButton!
    
    // MARK: - Private Property
    
    private var deviceOrientationMotion: QDeviceOrientation!
    private var deviceLastDirection: QDeviceOrientationState?
    
    private var frmCDL1DropDownMenu: QDropDownMenu = QDropDownMenu()
    private var frmCDL2DropDownMenu: QDropDownMenu = QDropDownMenu()
    private var frmCDL4DropDownMenu: QDropDownMenu = QDropDownMenu()
    private var frmCDL5DropDownMenu: QDropDownMenu = QDropDownMenu()
    private var frmCDL7DropDownMenu: QDropDownMenu = QDropDownMenu()
    private var frmCDL8DropDownMenu: QDropDownMenu = QDropDownMenu()
    private var frmCDL9DropDownMenu: QDropDownMenu = QDropDownMenu()
    private var frmCDL10DropDownMenu: QDropDownMenu = QDropDownMenu()
    private var frmCDL11DropDownMenu: QDropDownMenu = QDropDownMenu()
    private var frmCDL12DropDownMenu: QDropDownMenu = QDropDownMenu()
    private var frmCDL17DropDownMenu: QDropDownMenu = QDropDownMenu()
    
    // Data

    private let ListIdData: [Int] = [
        1, 2, 4, 5, 7, 8, 9, 10, 11, 12, 17
    ]
    
    private let SelectNumData: [[String]] = [
        ["0", "1", "2"],
        ["0", "1", "2"],
        ["0", "1"],
        ["0", "1"],
        ["0", "1"],
        ["0", "1"],
        ["0", "1"],
        ["0", "6", "12"],
        ["0", "1", "2"],
        ["0", "1", "2"],
        ["0", "1", "2"]
    ]
    
    // View
    
    var panGesture: UIPanGestureRecognizer = UIPanGestureRecognizer()
                                
    private var dropDownButtons: [UIButton] {
        return [
            self.frmCDL1Button,
            self.frmCDL2Button,
            self.frmCDL4Button,
            self.frmCDL5Button,
            self.frmCDL7Button,
            self.frmCDL8Button,
            self.frmCDL9Button,
            self.frmCDL10Button,
            self.frmCDL11Button,
            self.frmCDL12Button,
            self.frmCDL17Button
        ]
    }
    
    private var dropDownMenus: [QDropDownMenu] {
        return [
            frmCDL1DropDownMenu,
            frmCDL2DropDownMenu,
            frmCDL4DropDownMenu,
            frmCDL5DropDownMenu,
            frmCDL7DropDownMenu,
            frmCDL8DropDownMenu,
            frmCDL9DropDownMenu,
            frmCDL10DropDownMenu,
            frmCDL11DropDownMenu,
            frmCDL12DropDownMenu,
            frmCDL17DropDownMenu
        ]
    }
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Init View
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.initNavigationBar()
        self.initBackPanGesture()
        self.initialQDropDownMenu()
        self.initOrientationStatus()
        self.initShowingDatas()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.stopDeviceOrientationMonitor()
        enableBackPanGesture()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    // MARK: - Showing Datas
    
    func initShowingDatas() {
        
        
        if self.calculateType == .takeoff && UserSession.CurrentSession().takeoffCDLDatas != nil {
            self.setShowingDatas(UserSession.CurrentSession().takeoffCDLDatas!)
        }
        
        if self.calculateType == .landing && UserSession.CurrentSession().landingCDLDatas != nil {
            self.setShowingDatas(UserSession.CurrentSession().landingCDLDatas!)
        }
    }
    
    func setShowingDatas(_ datas: [Int]) {
        
        var frmCDLDatas: [Int] = datas
        frmCDLDatas.remove(at: 0)
        
        var index: Double = 0
        var listIdIndex: Int = 0
        
        for value: Int in frmCDLDatas {
            index += 1
            if index.truncatingRemainder(dividingBy: 2.0) == 0 {
                listIdIndex = ListIdData.index(of: frmCDLDatas[Int(index) - 2])!
                self.dropDownButtons[listIdIndex].setTitle(String(value), for: .normal)
            }
        }
    }
    
    // MARK: - User Event Handle
    
    // MARK: Click
    
    @IBAction func frmCDLButtonDidClick(_ sender: UIButton) {
        
        self.dropDownMenus[sender.tag].delegate = self
        self.hideOtherDropDownMenu(dropDownMenu: self.dropDownMenus[sender.tag])
        self.showDropDownMenu(dropDownMenu: self.dropDownMenus[sender.tag],
                                    titles: self.SelectNumData[sender.tag],
                                    button: sender,
                                 direction: "down")
    }
    
    @objc func cancelButtonDidClick(button: UIButton) {
        
        pushBackVC()
    }
    
    @objc func setButtonDidClick(button: UIBarButtonItem) {
        
        let frmCDLValues: [Int] = [
            Int(self.frmCDL1Button.titleLabel?.text ?? "0")!,
            Int(self.frmCDL2Button.titleLabel?.text ?? "0")!,
            Int(self.frmCDL4Button.titleLabel?.text ?? "0")!,
            Int(self.frmCDL5Button.titleLabel?.text ?? "0")!,
            Int(self.frmCDL7Button.titleLabel?.text ?? "0")!,
            Int(self.frmCDL8Button.titleLabel?.text ?? "0")!,
            Int(self.frmCDL9Button.titleLabel?.text ?? "0")!,
            Int(self.frmCDL10Button.titleLabel?.text ?? "0")!,
            Int(self.frmCDL11Button.titleLabel?.text ?? "0")!,
            Int(self.frmCDL12Button.titleLabel?.text ?? "0")!,
            Int(self.frmCDL17Button.titleLabel?.text ?? "0")!
        ]
        
        var frmCDLDatas: [Int]? = nil
        var frmCDLItemCount: Int = 0
        var index: Int = 0
        
        for value: Int in frmCDLValues {
            if value != 0 {
                frmCDLItemCount += 1
                if frmCDLDatas == nil {
                    frmCDLDatas = [frmCDLItemCount, ListIdData[index], value]
                } else {
                    frmCDLDatas![0] = frmCDLItemCount
                    frmCDLDatas!.append(ListIdData[index])
                    frmCDLDatas!.append(value)
                }
            }
            index += 1
        }
        
        switch self.calculateType {

            case .takeoff:
                UserSession.CurrentSession().takeoffCDLDatas = frmCDLDatas

            case .landing:
                UserSession.CurrentSession().landingCDLDatas = frmCDLDatas

            default:
                break
        }
        
        pushBackVC()
    }
    
    @objc func resetButtonDidClick(button: UIBarButtonItem) {
        
        for button: UIButton in self.dropDownButtons {
            button.setTitle(self.SelectNumData[button.tag][0], for: .normal)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.hideAllDropDownMenu()
    }
    
    // MARK: - Navigation Bar
    
    func initNavigationBar() {
        
        setNavigationBarTitle()
        setNavigationBarLeftButton()
        setNavigationBarRightButton()
    }
    
    func setNavigationBarTitle() {
        
        Q_NavigationItemTitleSet(self, Q_LocalizedString("FrmCDL.title"))
    }
    
    func setNavigationBarLeftButton() {
        
        Q_NavigationItemLeftTitleButtonSet(self,
                                           Q_LocalizedString("Public.cancel"),
                                           #selector(cancelButtonDidClick(button:)))
    }
    
    func setNavigationBarRightButton() {
        
        Q_NavigationItemRightTitleButtonsSet(self,
                                             Q_LocalizedString("Public.reset"),
                                             #selector(resetButtonDidClick(button:)),
                                             Q_LocalizedString("Public.done"),
                                             #selector(setButtonDidClick(button:)))
    }
    
    // MARK: - QDropDownMenu
    
    func initialQDropDownMenu() {
        
        for button: UIButton in self.dropDownButtons {
            button.setTitle(self.SelectNumData[button.tag][0], for: .normal)
        }
        
        for menu: QDropDownMenu in self.dropDownMenus {
            menu.tag = 1000
        }
    }
    
    func showDropDownMenu(dropDownMenu: QDropDownMenu,
                           titles: [String],
                           button: UIButton,
                           direction: String) {

        let frame: CGRect = button.frame
        let btnFrame: CGRect = CGRect(x: frame.origin.x,
                                      y: frame.origin.y + 70,
                                      width: frame.size.width,
                                      height: frame.size.height)
        if dropDownMenu.tag == 1000 {
            dropDownMenu.show(button,
                              withButtonFrame: btnFrame,
                              arrayOfTitle: titles,
                              arrayOfImage: nil,
                              animationDirection: direction)
            self.view.addSubview(dropDownMenu)
            dropDownMenu.tag = 2000
        } else {
            dropDownMenu.hide(withBtnFrame: btnFrame)
            dropDownMenu.tag = 1000
        }
    }
    
    func hideOtherDropDownMenu(dropDownMenu: QDropDownMenu) {
        
        for menu: QDropDownMenu in self.dropDownMenus {
            if menu != dropDownMenu {
                let index: Int = dropDownMenus.index(of: menu)!
                let frame: CGRect = self.dropDownButtons[index].frame
                let btnFrame: CGRect = CGRect(x: frame.origin.x,
                                              y: frame.origin.y + 70,
                                              width: frame.size.width,
                                              height: frame.size.height)
                menu.hide(withBtnFrame: btnFrame)
                menu.tag = 1000
            }
        }
    }
    
    func hideAllDropDownMenu() {
        
        for menu: QDropDownMenu in self.dropDownMenus {
            let index: Int = dropDownMenus.index(of: menu)!
            let frame: CGRect = self.dropDownButtons[index].frame
            let btnFrame: CGRect = CGRect(x: frame.origin.x,
                                          y: frame.origin.y + 70,
                                          width: frame.size.width,
                                          height: frame.size.height)
            menu.hide(withBtnFrame: btnFrame)
            menu.tag = 1000
        }
    }
    
    // MARK: QDropDownMenuDelegate

    func setDropDown(_ sender: QDropDownMenu!, title: String!) {
        
        sender.tag = 1000
    }
    
    // MARK: - QOrientationStatus
    
    func initOrientationStatus() {
        
        startDeviceOrientationMonitor()
        self.deviceLastDirection = Q_DeviceOrientation()
    }
    
    func startDeviceOrientationMonitor() {
        
        self.deviceOrientationMotion = QDeviceOrientation(delegate: self,
                                                  defaultDirection: Q_DeviceInterfaceOrientation())
        self.deviceOrientationMotion.q_startMonitor()
    }

    func stopDeviceOrientationMonitor() {
        
        self.deviceOrientationMotion.q_stopMonitor()
    }
    
    func q_devicenOrientationDidChanged() {
        
        let direction: QDeviceOrientationState = Q_DeviceOrientation()
        
        if Q_DeviceOrientationIsFace(direction)  ||
           self.deviceLastDirection == direction {
            return
        }
        
        self.deviceLastDirection = direction
        
        self.hideAllDropDownMenu()
    }
    
    // MARK: - Back Pan Gesture
    
    func initBackPanGesture() {
        
        disableBackPanGesture()
    }
    
    func enableBackPanGesture() {
        
        QM_NAVIGATION_BACK_GESTURE_ENABLE(self, self.panGesture)
    }
    
    func disableBackPanGesture() {
        
        self.panGesture = QM_NAVIGATION_BACK_GESTURE_DISABLE(self)
    }
    
    // MARK: - Navigation
    
    func pushBackVC() {
        
        Q_PopViewController(self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
    }

}
