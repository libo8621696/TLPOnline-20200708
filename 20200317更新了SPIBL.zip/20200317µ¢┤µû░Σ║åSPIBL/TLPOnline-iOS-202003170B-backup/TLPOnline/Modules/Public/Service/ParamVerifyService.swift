//
//  ParamVerifyService.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/14.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit


// MARK: Verify

func AirportIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}

func RunwayIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}

func RwConditionIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}

func AntiIceIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}

func LdgConfIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}

func BreakModeIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}

func ReversersIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}

func OatIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 &&
       value!.q_isValidNum() {
        
        let dValue: Double = (value! as NSString).doubleValue
        if dValue >= -40.0 &&
            dValue <= 55.0 {
            return true
        }
    }
    return false
}

func QnhIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 &&
       value!.q_isValidNum() {
        
        let dValue: Double = (value! as NSString).doubleValue
        if dValue >= 950.0 &&
            dValue <= 1100.0 {
            return true
        }
    }
    return false
}

func WindIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 &&
       value!.q_isValidNum() {
        
        let dValue: Double = (value! as NSString).doubleValue
        if dValue >= -10.0 &&
            dValue <= 40.0 {
            return true
        }
    }
    return false
}

func TakeoffWIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 &&
       value!.q_isValidNum() {
        
        let dValue: Double = (value! as NSString).doubleValue
        if dValue >= 26995.0 &&
            dValue <= 43500.0 {
            return true
        }
    }
    return false
}
