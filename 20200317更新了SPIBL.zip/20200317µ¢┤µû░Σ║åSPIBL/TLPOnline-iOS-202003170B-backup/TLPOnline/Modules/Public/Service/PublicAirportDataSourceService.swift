//
//  PublicAirportDataSourceService.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/17.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class PublicAirportDataSourceService: NSObject {
    
    // MARK: - Internal Methods
    
    // MARK: Airport
    
    func loadAirports(success successBlock: ((_ result: [AirportModel]) -> Void)?,
                      failure failureBlock: ((_ error: Error) -> Void)?) {

        ApiClient.DefaultClient()
            .retrieveAirportData(
            success: { (result: [String : Any]?) in

                let (isEmpty, error) = RequestResponseResultArrayObjectEmptyValidate(result: result)
                if isEmpty == true {
                    if failureBlock != nil {
                        failureBlock!(error!)
                    }
                    return
                }

                let airportDataArr: [[String: Any]] = (result!["result"] as? [[String: Any]])!

                var airportModels: [AirportModel] = [AirportModel]()

                for obj: [String: Any] in airportDataArr {

                    let airportModel  = AirportModel(withDict: obj)
                    airportModels.append(airportModel)
                }

                if successBlock != nil {
                    successBlock!(airportModels)
                }

            }, failure: { (error: Error?) in

                let err = RequestResponseErrorNullObjectValidate(error: error)
                if failureBlock != nil {
                    failureBlock!(err)
                }
            })
    }
    
    // MARK: Load Runway

    func loadRunway(withAirportCode airportCode: String,
                            success successBlock: ((_ result: [RunwayModel]) -> Void)?,
                            failure failureBlock: ((_ error: Error) -> Void)?) {

        ApiClient.DefaultClient()
            .retrieveRunwayData(withAirportCode: airportCode,
            success: { (result: [String : Any]?) in

                let (isEmpty, error) = RequestResponseResultArrayObjectEmptyValidate(result: result)
                if isEmpty == true {
                    if failureBlock != nil {
                        failureBlock!(error!)
                    }
                    return
                }

                let runwayDataArr: [[String: Any]] = (result!["result"] as? [[String: Any]])!

                let runwayDataSortArr: [[String: Any]]  = runwayDataArr.sorted { (a: [String : Any], b: [String : Any]) -> Bool in
                    
                    return (a["Designation"] as! String) < (b["Designation"] as! String)
                }
                
                var runwayModels: [RunwayModel] = [RunwayModel]()

                for obj: [String: Any] in runwayDataSortArr {

                    let runwayModel  = RunwayModel(withDict: obj)
                    runwayModels.append(runwayModel)
                }

                if successBlock != nil {
                    successBlock!(runwayModels)
                }

            }, failure: { (error: Error?) in

                let err = RequestResponseErrorNullObjectValidate(error: error)
                if failureBlock != nil {
                    failureBlock!(err)
                }
            })
    }
    
}
