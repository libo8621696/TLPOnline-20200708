//
//  LandingViewController.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class LandingViewController: PublicBaseViewController, UITextFieldDelegate,
                             QDropDownMenuDelegate, QDeviceOrientationDelegate,
                             QAlertListViewDelegate {
    
    // MARK: - Internal Property
    
    
    // MARK: - IBOutlet Property
    
    @IBOutlet weak var airportPromptLabel: UILabel!
    @IBOutlet weak var oatPromptLabel: UILabel!
    @IBOutlet weak var windPromptLabel: UILabel!
    @IBOutlet weak var brakeModePromptLabel: UILabel!
    @IBOutlet weak var rwConditionPromptLabel: UILabel!
    @IBOutlet weak var runwayPromptLabel: UILabel!
    @IBOutlet weak var qnhPromptLabel: UILabel!
    @IBOutlet weak var ldgConfPromptLabel: UILabel!
    @IBOutlet weak var reversersPromptLabel: UILabel!
    
    @IBOutlet weak var oatTextField: UITextField!
    @IBOutlet weak var windTextField: UITextField!
    @IBOutlet weak var qnhTextField: UITextField!
    
    @IBOutlet weak var airportButton: UIButton!
    @IBOutlet weak var brakeModeButton: UIButton!
    @IBOutlet weak var rwConditionButton: UIButton!
    @IBOutlet weak var runwayButton: UIButton!
    @IBOutlet weak var ldgConfButton: UIButton!
    @IBOutlet weak var reversersButton: UIButton!
    
    @IBOutlet weak var calculateButton: UIButton!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var cdlItemsButton: UIButton!
    
    @IBOutlet weak var aldLabel: UILabel!
    @IBOutlet weak var rldLabel: UILabel!
    @IBOutlet weak var mlwLabel: UILabel!
    @IBOutlet weak var vappLabel: UILabel!
    
    // MARK: - Private Property
    
    private var deviceOrientationMotion: QDeviceOrientation!
    private var deviceLastDirection: QDeviceOrientationState?
    
    private var airportDropDownMenu: QDropDownMenu = QDropDownMenu()
    private var brakeModeDropDownMenu: QDropDownMenu = QDropDownMenu()
    private var rwConditionDropDownMenu: QDropDownMenu = QDropDownMenu()
    private var runwayDropDownMenu: QDropDownMenu = QDropDownMenu()
    private var ldgConfDropDownMenu: QDropDownMenu = QDropDownMenu()
    private var reversersDropDownMenu: QDropDownMenu = QDropDownMenu()
    
    // Data
    private var resultShowingDatas: CalculateResultModel!
    
    private var airportDatas: [String] = []
    private var runwayDatas: [String] = []
    
    private let brakeModeDatas: [String] = [
        Q_LocalizedString("Landing.brakeMode.MaxPedal"),
        Q_LocalizedString("Landing.brakeMode.LOW"),
        Q_LocalizedString("Landing.brakeMode.MED"),
        Q_LocalizedString("Landing.brakeMode.HIGH"),
    ]

    private let rwConditionDatas: [String] = [
        Q_LocalizedString("Landing.rwCondition.Dry"),
        Q_LocalizedString("Landing.rwCondition.Wet"),
        Q_LocalizedString("Landing.rwCondition.6.3mmWater"),
        Q_LocalizedString("Landing.rwCondition.12.7mmWater"),
        Q_LocalizedString("Landing.rwCondition.6.3mmSlush"),
        Q_LocalizedString("Landing.rwCondition.12.7mmSlush"),
        Q_LocalizedString("Landing.rwCondition.5mmWetSnow"),
        Q_LocalizedString("Landing.rwCondition.12.7mmWetSnow"),
        Q_LocalizedString("Landing.rwCondition.10mmDrySnow"),
        Q_LocalizedString("Landing.rwCondition.12.7mmDrySnow"),
        Q_LocalizedString("Landing.rwCondition.CompactSnow"),
        Q_LocalizedString("Landing.rwCondition.Ice")
    ]
    
    private let ldgConfDatas: [String] = [
        Q_LocalizedString("Landing.ldgConf.CONF3"),    // 2
        Q_LocalizedString("Landing.ldgConf.CONF4")     // 3
    ]
    
    private let reversersDatas: [String] = [
        Q_LocalizedString("Landing.reversers.Inoperative"),
        Q_LocalizedString("Landing.reversers.Operative")
    ]
    
    // View
    
    var coverView: UIButton!
    var alertListView: QAlertListView!
    
    private enum TargetViewTag: Int {
        case airport = 0
        case oat = 1
        case wind = 2
        case brakeMode = 3
        case rwCondition = 4
        case runway = 5
        case qnh = 6
        case ldgConf = 7
        case reversers = 8
    }
    
    private var textFields: [UITextField] {
        return [
            self.oatTextField,
            self.windTextField,
            self.qnhTextField
        ]
    }
    
    private var dropDownButtons: [UIButton] {
        return [
            self.airportButton,
            self.brakeModeButton,
            self.rwConditionButton,
            self.runwayButton,
            self.ldgConfButton,
            self.reversersButton
        ]
    }
    
    private var dropDownMenus: [QDropDownMenu] {
        return [
            airportDropDownMenu,
            brakeModeDropDownMenu,
            rwConditionDropDownMenu,
            runwayDropDownMenu,
            ldgConfDropDownMenu,
            reversersDropDownMenu
        ]
    }
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Init View
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.initNavigationBar()
        self.initTextField()
        self.initialQDropDownMenu()
        self.initOrientationStatus()
        self.initShowingDatas()
        self.initResultDatas()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        setNavigationBarLogo()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.hideQAlertListView()
        self.stopDeviceOrientationMonitor()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    // MARK: - Showing Datas
    
    func initShowingDatas() {
        
        self.loadAirportDatas()
    }
    
    // MARK: Airport
    
    func loadAirportDatas() {
        
        if UserSession.CurrentSession().landingAirportModels != nil {

            self.initialAirportShowingDatas(UserSession.CurrentSession().landingAirportModels!)
            return
        }
        
        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Public.loading"), true)
        
        PublicAirportDataSourceService()
            .loadAirports(success: { (result: [AirportModel]) in

                UserSession.CurrentSession().landingAirportModels = result
                self.loadAirportSuccessAction(result)
                
            }, failure: { (error: Error) in

                UserSession.CurrentSession().landingAirportModels = nil
                self.loadAirportFailureAction(error)
            })
    }
    
    func loadAirportSuccessAction(_ result: [AirportModel]) {
        
        self.hideHudMain(hud: self.hud)

        self.setAirportShowingDatas(result)
    }
    
    func loadAirportFailureAction(_ error: Error) {

        self.hideHudMain(hud: self.hud)
        
        self.airportDatas = []
        
        switch (error as NSError).code {
            
            case RequestResponseCode.loadDataFailure.rawValue,
                 RequestResponseCode.responseObjectIsEmpty.rawValue:
                QF_AlertShow_Note_Main(self, Q_LocalizedString("RequestResponse.code.loadAirportDataFailure"))
            
            default:
                RequestResponseErrorAlert(error: error,
                                         target: self,
                                   defaultBlock: {
                                       QF_AlertShow_Note_Main(self, RequestResponseCode.loadDataFailure.localValue)
                                   })
        }
    }
    
    func initialAirportShowingDatas(_ airportModels: [AirportModel]) {
        
        self.airportDatas.removeAll()
        
        airportModels.forEach { (airport: AirportModel) in
            if airport.ICAOCode != nil {
                self.airportDatas.append(airport.ICAOCode ?? "")
            }
        }
    }
    
    func setAirportShowingDatas(_ airportModels: [AirportModel]) {
        
        self.initialAirportShowingDatas(airportModels)

        if self.airportDatas.count > 0 {
            self.airportButton.setTitle(self.airportDatas[0], for: .normal)
            self.runwayButton.setTitle(nil, for: .normal)
            self.runwayButton.titleLabel?.text = nil
            self.runwayPromptLabel.text = ""
            self.loadRunwayDatas(withAiportCode: self.airportButton.titleLabel?.text ?? "")
        }
    }
    
    // MARK: Runway
    
    @objc func loadRunwayDatas(withAiportCode airportCode: String) {
        
        if UserSession.CurrentSession().runwayModels != nil &&
           UserSession.CurrentSession().runwayModels?[airportCode] != nil {

            self.setRunwayShowingDatas(UserSession.CurrentSession().runwayModels![airportCode]!)
            return
        }
        
        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Public.loading"), true)
        
        PublicAirportDataSourceService()
        .loadRunway(withAirportCode: airportCode,
            success: { (result: [RunwayModel]) in
                
                if UserSession.CurrentSession().runwayModels == nil {
                    UserSession.CurrentSession().runwayModels = [:]
                }
                UserSession.CurrentSession().runwayModels![airportCode] = result
                self.loadRunwaySuccessAction(result)
                
            }, failure: { (error: Error) in
                
                if UserSession.CurrentSession().runwayModels != nil {
                    UserSession.CurrentSession().runwayModels![airportCode] = nil
                }
                self.loadRunwayFailureAction(error)
            })
    }
    
    func loadRunwaySuccessAction(_ result: [RunwayModel]) {
        
        self.hideHudMain(hud: self.hud)

        self.setRunwayShowingDatas(result)
    }
    
    func loadRunwayFailureAction(_ error: Error) {

        self.hideHudMain(hud: self.hud)
        
        self.runwayDatas = []
        
        switch (error as NSError).code {
            
            case RequestResponseCode.loadDataFailure.rawValue,
                 RequestResponseCode.responseObjectIsEmpty.rawValue:
                QF_AlertShow_Note_Main(self, Q_LocalizedString("RequestResponse.code.loadRunwayDataFailure"))
            
            default:
                RequestResponseErrorAlert(error: error,
                                         target: self,
                                   defaultBlock: {
                                       QF_AlertShow_Note_Main(self, RequestResponseCode.loadDataFailure.localValue)
                                   })
        }
    }
    
    func setRunwayShowingDatas(_ airportModels: [RunwayModel]) {
        
        self.runwayDatas.removeAll()
        
        airportModels.forEach { (airport: RunwayModel) in
            if airport.ICAOCode != nil {
                self.runwayDatas.append(airport.Designation ?? "")
            }
        }
        
        if self.runwayDatas.count > 0 {
            self.runwayButton.setTitle(self.runwayDatas[0], for: .normal)
            self.runwayPromptLabel.text = ""
        }
    }
    
    // MARK: - Result Datas
    
    func initResultDatas() {
        
        self.setResultDatas()
    }
    
    func reSetResultDatas() {
        
        self.setResultDatas()
    }
    
    func setResultDatas() {
        
        guard let result = self.resultShowingDatas else {
            
            self.clearResultDatas()
            return
        }

        self.aldLabel.text = (result.ALD != nil) ? "\(result.ALD!) m" : ""
        self.rldLabel.text = (result.RLD != nil) ? "\(result.RLD!) m" : ""
        self.mlwLabel.text = (result.MLW != nil) ? "\(result.MLW!) kg" : ""
        self.vappLabel.text = (result.VApp != nil) ? "\(result.VApp!) Kt" : ""
    }
    
    func clearResultDatas() {
        
        self.resultShowingDatas = nil
        self.aldLabel.text = ""
        self.rldLabel.text = ""
        self.mlwLabel.text = ""
        self.vappLabel.text = ""
    }
    
    // MARK: - User Event Handle
    
    // MARK: Click
    
    @IBAction func airportButtonDidClick(_ sender: UIButton) {
        
        self.hideAllDropDownMenu()
        self.textFields.forEach { (tf: UITextField) in
            tf.resignFirstResponder()
        }
        
        self.showQAlertListView()
        
        //self.airportDropDownMenu.delegate = self
        //self.hideOtherDropDownMenu(dropDownMenu: airportDropDownMenu)
        //self.showDropDownMenu(dropDownMenu: self.airportDropDownMenu,
        //                      titles: self.airportDatas,
        //                      button: sender,
        //                      direction: "down")
    }
    
    @IBAction func brakeModeButtonDidClick(_ sender: UIButton) {
        
        self.brakeModeDropDownMenu.delegate = self
        self.hideOtherDropDownMenu(dropDownMenu: brakeModeDropDownMenu)
        self.showDropDownMenu(dropDownMenu: self.brakeModeDropDownMenu,
                              titles: self.brakeModeDatas,
                              button: sender,
                              direction: "down")
    }
    
    @IBAction func rwConditionButtonDidClick(_ sender: UIButton) {
        
        self.rwConditionDropDownMenu.delegate = self
        self.hideOtherDropDownMenu(dropDownMenu: rwConditionDropDownMenu)
        self.showDropDownMenu(dropDownMenu: self.rwConditionDropDownMenu,
                              titles: self.rwConditionDatas,
                              button: sender,
                              direction: "down")
    }
    
    @IBAction func runwayButtonDidClick(_ sender: UIButton) {
        
        self.runwayDropDownMenu.delegate = self
        self.hideOtherDropDownMenu(dropDownMenu: runwayDropDownMenu)
        self.showDropDownMenu(dropDownMenu: self.runwayDropDownMenu,
                              titles: self.runwayDatas,
                              button: sender,
                              direction: "down")
    }
    
    @IBAction func ldgConfButtonDidClick(_ sender: UIButton) {
        
        self.ldgConfDropDownMenu.delegate = self
        self.hideOtherDropDownMenu(dropDownMenu: ldgConfDropDownMenu)
        self.showDropDownMenu(dropDownMenu: self.ldgConfDropDownMenu,
                              titles: self.ldgConfDatas,
                              button: sender,
                              direction: "down")
    }
    
    @IBAction func reversersButtonDidClick(_ sender: UIButton) {
        
        self.reversersDropDownMenu.delegate = self
        self.hideOtherDropDownMenu(dropDownMenu: reversersDropDownMenu)
        self.showDropDownMenu(dropDownMenu: self.reversersDropDownMenu,
                              titles: self.reversersDatas,
                              button: sender,
                              direction: "down")
    }
    
    @IBAction func calculateButtonDidClick(_ sender: UIButton) {
        
        if !AirportIsValid(self.airportButton.titleLabel?.text) ||
            !RunwayIsValid(self.runwayButton.titleLabel?.text) ||
            !OatIsValid(self.oatTextField.text != "" ? self.oatTextField.text : self.oatTextField.placeholder) ||
            !QnhIsValid(self.qnhTextField.text != "" ? self.qnhTextField.text : self.qnhTextField.placeholder) ||
            !WindIsValid(self.windTextField.text != "" ? self.windTextField.text : self.windTextField.placeholder) ||
            !LdgConfIsValid(self.ldgConfButton.titleLabel?.text) ||
            !BreakModeIsValid(self.brakeModeButton.titleLabel?.text) ||
            !ReversersIsValid(self.reversersButton.titleLabel?.text) ||
            !RwConditionIsValid(self.rwConditionButton.titleLabel?.text) {
            
            if !AirportIsValid(self.airportButton.titleLabel?.text) {
                self.airportPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.airport")
            }
            if !RunwayIsValid(self.runwayButton.titleLabel?.text) {
                self.runwayPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.runway")
            }
            
            QF_AlertShow_Note_Main(self, RequestResponseCode.invalidRequestParam.localValue)
            
            return
        }
        
        self.calculate()
    }
    
    @IBAction func clearButtonDidClick(_ sender: UIButton) {
        
        self.clear()
    }
    
    @IBAction func cdlItemsButtonDidClick(_ sender: UIButton) {
        
        self.pushToFrmCDLVC()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        self.hideAllDropDownMenu()
    }
    
    // MARK: Editing Changed
    
    @objc func textFieldDidChanged(textField: UITextField) {

        if textField.text != "" {
            setPromptMsg(withTag: textField.tag)
        }
    }
    
    // MARK: Calculate
    
    func calculate() {

        self.clearResultDatas()
        
        let airportValue: String = self.airportButton.titleLabel?.text ?? ""
        let runwayValue: String = self.runwayButton.titleLabel?.text ?? ""
        let oatValue = Double((self.oatTextField.text != "" ? self.oatTextField.text: self.oatTextField.placeholder)!)
        let qnhValue = Double((self.qnhTextField.text != "" ? self.qnhTextField.text : self.qnhTextField.placeholder)!)
        let windValue = Double((self.windTextField.text != "" ? self.windTextField.text : self.windTextField.placeholder)!)
        let rwConditionValue = self.rwConditionDatas.index(of: self.rwConditionButton.titleLabel?.text ?? "")
        let ldgConfValue = self.ldgConfDatas.index(of: self.ldgConfButton.titleLabel?.text ?? "")! + 2
        let brakeModeValue = self.brakeModeDatas.index(of: self.brakeModeButton.titleLabel?.text ?? "")
        let reversersValue = self.reversersDatas.index(of: self.reversersButton.titleLabel?.text ?? "")
        
        let calculate: CalculateParamModel = CalculateParamModel()
        calculate.airport = airportValue
        calculate.runway = runwayValue
        calculate.oat = NSNumber(value: oatValue!)
        calculate.qnh = NSNumber(value: qnhValue!)
        calculate.wind = NSNumber(value: windValue!)
        calculate.rwCondition = NSNumber(value: rwConditionValue!)
        calculate.ldgConf = NSNumber(value: ldgConfValue)
        calculate.brakeMode = NSNumber(value: brakeModeValue!)
        calculate.reversers = NSNumber(value: reversersValue!)
        
        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Public.calculating"), true)

        PublicCalculateDataSourceService()
            .calculate(withType: .landing,
                         params: calculate,
            success: { (result: CalculateResultModel) in
                
                self.calculateSuccessAction(result)

            }) { (error: Error) in
                
                self.calculateFailureAction(error)
            }
    }
    
    func calculateSuccessAction(_ result: CalculateResultModel) {

        self.hideHudMain(hud: self.hud)
        
        self.resultShowingDatas = result
        self.setResultDatas()
    }

    func calculateFailureAction(_ error: Error) {

        self.hideHudMain(hud: self.hud)

        self.resultShowingDatas = nil
        
        switch (error as NSError).code {
            
            case RequestResponseCode.loadDataFailure.rawValue:
                QF_AlertShow_Note_Main(self, Q_LocalizedString("RequestResponse.code.loadCalculateDataFailure"))
            
            default:
                RequestResponseErrorAlert(error: error,
                                         target: self,
                                   defaultBlock: nil)
        }
    }
    
    // MARK: Clear
    
    func clear() {
        
        self.resultShowingDatas = nil
        self.setResultDatas()
    }
    
    // MARK: - Navigation Bar
    
    func initNavigationBar() {
        
        Q_NavigationBarTitleSet(self, Q_LocalizedString("Landing.title"))
    }
    
    func setNavigationBarLogo() {

        let image = UIImage(named: "icon-logo-r")
        Q_NavigationBarLeftImageButtonSet_image(self, image, nil)
        Q_NavigationBarLeftBarButtonItem(self)?.isEnabled = false
    }

    // MARK: - Prompt Msg

    func setPromptMsg(withTag tag: Int) {

        switch tag {
            
            case TargetViewTag.oat.rawValue:
                if OatIsValid(self.oatTextField.text) {
                    self.oatPromptLabel.text = ""
                } else {
                    self.oatPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.oat")
                }
            
            case TargetViewTag.qnh.rawValue:
                if QnhIsValid(self.qnhTextField.text) {
                    self.qnhPromptLabel.text = ""
                } else {
                    self.qnhPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.qnh")
                }
            
            case TargetViewTag.wind.rawValue:
                if WindIsValid(self.windTextField.text) {
                    self.windPromptLabel.text = ""
                } else {
                    self.windPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.wind")
                }
            
            default:
                break
        }
    }

    // MARK: - Text Field

    func initTextField() {

        for tf in self.textFields {

            tf.addTarget( self,
                  action: #selector(textFieldDidChanged(textField:)),
                     for: .editingChanged)
        }
    }

    // MARK: UITextFieldDelegate

    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if textField.text != "" {
            setPromptMsg(withTag: textField.tag)
        }
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        switch textField.tag {
            case self.oatTextField.tag:
                self.qnhTextField.becomeFirstResponder()
            case self.qnhTextField.tag:
                self.windTextField.becomeFirstResponder()
            default:
                self.windTextField.resignFirstResponder()
        }
        
        return true
    }
    
    // MARK: - QDropDownMenu
    
    func initialQDropDownMenu() {
        
        self.brakeModeButton.setTitle(self.brakeModeDatas[0], for: .normal)
        self.rwConditionButton.setTitle(self.rwConditionDatas[0], for: .normal)
        self.ldgConfButton.setTitle(self.ldgConfDatas[1], for: .normal)
        self.reversersButton.setTitle(self.reversersDatas[0], for: .normal)
        
        for menu: QDropDownMenu in self.dropDownMenus {
            menu.tag = 1000
        }
    }
    
    func showDropDownMenu(dropDownMenu: QDropDownMenu,
                           titles: [String],
                           button: UIButton,
                           direction: String) {

        let frame: CGRect = button.frame
        let btnFrame: CGRect = CGRect(x: frame.origin.x,
                                      y: frame.origin.y + 70,
                                      width: frame.size.width,
                                      height: frame.size.height)
        if dropDownMenu.tag == 1000 {
            dropDownMenu.show(button,
                              withButtonFrame: btnFrame,
                              arrayOfTitle: titles,
                              arrayOfImage: nil,
                              animationDirection: direction)
            self.view.addSubview(dropDownMenu)
            dropDownMenu.tag = 2000
        } else {
            dropDownMenu.hide(withBtnFrame: btnFrame)
            dropDownMenu.tag = 1000
        }
    }
    
    func hideOtherDropDownMenu(dropDownMenu: QDropDownMenu) {
        
        for menu: QDropDownMenu in self.dropDownMenus {
            if menu != dropDownMenu {
                let index: Int = dropDownMenus.index(of: menu)!
                let frame: CGRect = self.dropDownButtons[index].frame
                let btnFrame: CGRect = CGRect(x: frame.origin.x,
                                              y: frame.origin.y + 70,
                                              width: frame.size.width,
                                              height: frame.size.height)
                menu.hide(withBtnFrame: btnFrame)
                menu.tag = 1000
            }
        }
    }
    
    func hideAllDropDownMenu() {
        
        for menu: QDropDownMenu in self.dropDownMenus {
            let index: Int = dropDownMenus.index(of: menu)!
            let frame: CGRect = self.dropDownButtons[index].frame
            let btnFrame: CGRect = CGRect(x: frame.origin.x,
                                          y: frame.origin.y + 70,
                                          width: frame.size.width,
                                          height: frame.size.height)
            menu.hide(withBtnFrame: btnFrame)
            menu.tag = 1000
        }
    }
    
    // MARK: QDropDownMenuDelegate
    
    func setDropDown(_ sender: QDropDownMenu!, title: String!) {
        
        sender.tag = 1000
        
        if sender == self.airportDropDownMenu {
            self.airportPromptLabel.text = ""
            self.runwayButton.setTitle(nil, for: .normal)
            self.runwayButton.titleLabel?.text = nil
            self.runwayPromptLabel.text = ""
            self.loadRunwayDatas(withAiportCode: title)
        }
        if sender == self.runwayDropDownMenu {
            self.runwayPromptLabel.text = ""
        }
    }
    
    // MARK: - QAlertListView
    
    func showQAlertListView() {
        
        let width = self.view.bounds.size.width
        let height = self.view.bounds.size.height
        let h = (height > width ? width : height) * 0.7
        let w = h / 3.0 * 2.5
        
        self.coverView = UIButton(frame: UIScreen.main.bounds)
        self.coverView.backgroundColor = UIColor.black
        self.coverView.alpha = 0.2
        self.coverView.addTarget(self, action: #selector(coverViewDidClick), for: .touchUpInside)
        
        self.view.addSubview(self.coverView)
        
        self.alertListView = QAlertListView(frame: CGRect(x: 0, y: 0, width: w, height: h))
        self.alertListView.titleLabel.text = Q_LocalizedString("Pop.choose.airport")
        self.alertListView.delegate = self
        self.alertListView.center = self.view.center
        self.view.addSubview(self.alertListView)
        
        var airports: [[String: String]] = []
        if UserSession.CurrentSession().landingAirportModels != nil {
            UserSession.CurrentSession().landingAirportModels!.forEach { (airport: AirportModel) in
                if airport.ICAOCode != nil {
                    airports.append([
                        "AirportName": airport.AirportName ?? "",
                        "CityName": airport.CityName ?? "",
                        "CountryName": airport.CountryName ?? "",
                        "ICAOCode": airport.ICAOCode ?? "",
                        "IATACode": airport.IATACode ?? ""
                    ])
                }
            }
        }
        
        self.alertListView.datas = airports
    }
    
    func hideQAlertListView() {
        
        if self.coverView != nil {
            self.coverView.removeFromSuperview()
        }
        if self.alertListView != nil {
            self.alertListView.removeFromSuperview()
        }
    }
    
    @objc func coverViewDidClick() {
        
        self.hideQAlertListView()
    }
    
    // MARK: QAlertListViewDelegate
    
    func didSelectRow(atTitle title: String!) {
        
        self.hideQAlertListView()
        
        self.airportPromptLabel.text = ""
        self.airportButton.setTitle(title, for: .normal)
        self.runwayButton.setTitle(nil, for: .normal)
        self.runwayButton.titleLabel?.text = nil
        self.runwayPromptLabel.text = ""
        self.loadRunwayDatas(withAiportCode: title)
    }
    
    func cancelButtonDidClick() {
        
        self.hideQAlertListView()
    }
    
    // MARK: - QOrientationStatus
    
    func initOrientationStatus() {
        
        startDeviceOrientationMonitor()
        self.deviceLastDirection = Q_DeviceOrientation()
    }
    
    func startDeviceOrientationMonitor() {
        
        self.deviceOrientationMotion = QDeviceOrientation(delegate: self,
                                                          defaultDirection: Q_DeviceInterfaceOrientation())
        self.deviceOrientationMotion.q_startMonitor()
    }

    func stopDeviceOrientationMonitor() {
        
        self.deviceOrientationMotion.q_stopMonitor()
    }
    
    func q_devicenOrientationDidChanged() {
        
        let direction: QDeviceOrientationState = Q_DeviceOrientation()
        
        if Q_DeviceOrientationIsFace(direction)  ||
           self.deviceLastDirection == direction {
            return
        }
        
        self.deviceLastDirection = direction
        
        self.hideAllDropDownMenu()
        self.hideQAlertListView()
    }
    
    // MARK: - Navigation
    
    func pushToFrmCDLVC() {
        
        QF_PresentViewControllerWithSegueIdentifier(self, .frmCDL)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
       
        let vc: UIViewController = segue.destination
        
        switch vc {
            
            case is FrmCDLViewController:
                let v: FrmCDLViewController = vc as! FrmCDLViewController
                v.calculateType = .landing
            
            default:
                break
        }
    }
    
}
