//
//  AuthenticationLoginViewController.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class AuthenticationLoginViewController: PublicBaseViewController, UITextFieldDelegate {
    
    // MARK: - IBOutlet Property
    
    @IBOutlet weak var serverAddressPromptLabel: UILabel!
    @IBOutlet weak var accountPromptLabel: UILabel!
    @IBOutlet weak var passwordPromptLabel: UILabel!
    
    @IBOutlet weak var serverAddressTextField: UITextField!
    @IBOutlet weak var accountTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var loginButton: UIButton!
    
    // MARK: - Private Property
    
    // View
    
    enum TargetViewTag: Int {
        case serverAddress = 0
        case account = 1
        case password = 2
        case uuid = 3
    }

    var textFields: [UITextField] {
        return [
            self.serverAddressTextField,
            self.accountTextField,
            self.passwordTextField
        ]
    }
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Init View
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.initNavigationBar()
        self.initServerAddressTextField()
        self.initAccountTextField()
        self.initTextField()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //initKeyboardStatus()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    // MARK: - User Event Handle
    
    // MARK: Click
    
    @IBAction func loginButtonDidClick(_ sender: UIButton) {
        
        if !ServerAddressIsValid(self.serverAddressTextField.text) ||
            !AccountIsValid(self.accountTextField.text) ||
            !PasswordIsValid(self.passwordTextField.text) {
            
            if !ServerAddressIsValid(self.serverAddressTextField.text) {
                self.serverAddressPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.serverAddress")
            }
            if !AccountIsValid(self.accountTextField.text) {
                self.accountPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.account")
            }
            if !PasswordIsValid(self.passwordTextField.text) {
                self.passwordPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.password")
            }
            return
        }
        
        self.setServerAddress()
        
        login()
    }
    
    // MARK: Editing Changed
    
    @objc func textFieldDidChanged(textField: UITextField) {

        switch textField.tag {
            
            case TargetViewTag.serverAddress.rawValue:
                if self.serverAddressPromptLabel.text != "" {
                    setPromptMsg(withTag: textField.tag)
                }

            case TargetViewTag.account.rawValue:
                if self.accountPromptLabel.text != "" {
                    setPromptMsg(withTag: textField.tag)
                }

            case TargetViewTag.password.rawValue:
                if self.passwordPromptLabel.text != "" {
                    setPromptMsg(withTag: textField.tag)
                }

            default:
                break
        }
    }
    
    // MARK: - login

    func login() {

        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Auth.logining"), true)
        let InstaransObject:MAC = MAC()
               
        let UUIDinfo = InstaransObject.getUUID()
        
        let password_original = self.passwordTextField.text
        

         AuthenticationLoginDataSourceService()
            .userLogin(withAccount: self.accountTextField.text,
                          password: password_original,
                          uuid: "\(UUIDinfo ?? "unknown_UUID")",
               success: { (success: Bool, result: [String: Any]?) in
                
                self.showActionResult(toHud: self.hud, withMessage: Q_LocalizedString("Auth.login.success"))
                Q_Dispatch_After(0.5, {
                    self.hideHudMain(hud: self.hud)
                    self.pushToHomeVC()
                })

            }) { (error: Error) in

                self.hideHudMain(hud: self.hud)

                switch (error as NSError).code {

                    case RequestResponseCode.responseObjectIsEmpty.rawValue:
                        QF_AlertShow_Note_Main(self, RequestResponseCode.loadDataFailure.localValue)

                    case RequestResponseCode.userNameOrPasswordIsInvalid.rawValue:
                        QF_AlertShow_Note_Main(self, RequestResponseCode.userNameOrPasswordIsInvalid.localValue)
                    
                    

                    default:
                        RequestResponseErrorAlert(error: error,
                                                 target: self,
                                           defaultBlock: {
                                               QF_AlertShow_Note_Main(self, RequestResponseCode.loginFailure.localValue)
                                           })
                }
            }
    }

    // MARK: - Navigation Bar

    func initNavigationBar() {
        Q_NavigationBarHideSet(self, true)
    }

    // MARK: - Server Address
    
    func initServerAddressTextField() {
        
        let lastLoginServerAddress = Q_UserDefaultsObjectGet(API_ROOT_URL_KEY) as? String ?? API_ROOT_DEFAULT_URL
        self.serverAddressTextField.text = lastLoginServerAddress
    }
    
    func setServerAddress() {
        
        Q_UserDefaultsObjectSet(self.serverAddressTextField.text!, API_ROOT_URL_KEY)
    }
    
    // MARK: - Account

    func initAccountTextField() {

        let lastLoginUserName = AuthenticationSecurityService().retrieveLocalUserLoginUserName()
        self.accountTextField.text = lastLoginUserName
    }

    func accountIsEmpty() -> Bool {

        if self.accountTextField.text == nil ||
           self.accountTextField.text?.q_length() == 0 {
            return true
        }
        return false
    }

    // MARK: - Prompt Msg

    func setPromptMsg(withTag tag: Int) {

        switch tag {
            
            case TargetViewTag.serverAddress.rawValue:
                if ServerAddressIsValid(self.serverAddressTextField.text) {
                    self.serverAddressPromptLabel.text = ""
                } else {
                    self.serverAddressPromptLabel.text = AuthVerifyMsgType.serverAddress.localValue
                }

            case TargetViewTag.account.rawValue:
                if AccountIsValid(self.accountTextField.text) {
                    self.accountPromptLabel.text = ""
                } else {
                    self.accountPromptLabel.text = AuthVerifyMsgType.account.localValue
                }

            case TargetViewTag.password.rawValue:
                if PasswordIsValid(self.passwordTextField.text) {
                    self.passwordPromptLabel.text = ""
                } else {
                    self.passwordPromptLabel.text = AuthVerifyMsgType.password.localValue
                }

            default:
                break
        }
    }

    // MARK: - Text Field

    func initTextField() {

        for tf in self.textFields {

            tf.addTarget( self,
                  action: #selector(textFieldDidChanged(textField:)),
                     for: .editingChanged)
        }
    }

    // MARK: UITextFieldDelegate

    func textFieldDidEndEditing(_ textField: UITextField) {

        setPromptMsg(withTag: textField.tag)
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        switch textField.tag {
            
            case TargetViewTag.serverAddress.rawValue:
                self.accountTextField.becomeFirstResponder()

            case TargetViewTag.account.rawValue:
                self.passwordTextField.becomeFirstResponder()

            case TargetViewTag.password.rawValue:
                self.passwordTextField.resignFirstResponder()
                login()

            default:
                break
        }

        return true
    }

    // MARK: - Keyboard
    
    func initKeyboardStatus() {
        
        if accountIsEmpty() {
            self.accountTextField.becomeFirstResponder()
        } else {
            self.passwordTextField.becomeFirstResponder()
        }
    }
    
    // MARK: - Navigation
    
    func pushToHomeVC() {
        Q_NotificationPost(USER_LOGIN_AUTHENTICATION_SUCCESS_NOTIFICATION, nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
    }

}
