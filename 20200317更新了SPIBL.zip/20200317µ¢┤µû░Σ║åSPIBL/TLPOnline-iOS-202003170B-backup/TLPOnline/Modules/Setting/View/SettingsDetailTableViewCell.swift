//
//  SettingsDetailTableViewCell.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class SettingsDetailTableViewCell: UITableViewCell {
    
    // MARK: - Internal Property
    
    
    // MARK: - IBOutlet Property
    
    @IBOutlet weak var valueSwitch: UISwitch!
    @IBOutlet weak var valueTextField: UITextField!
    @IBOutlet weak var textCenterLabel: UILabel!
    
    // MARK: - Private Property
    
    
    // MARK: - Internal Methods
    
    class func cell(_ tableView: UITableView, identifier: String) -> SettingsDetailTableViewCell {
        
        return tableView.dequeueReusableCell(withIdentifier: identifier) as! SettingsDetailTableViewCell
    }
    
    // MARK: - Private Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }

}
