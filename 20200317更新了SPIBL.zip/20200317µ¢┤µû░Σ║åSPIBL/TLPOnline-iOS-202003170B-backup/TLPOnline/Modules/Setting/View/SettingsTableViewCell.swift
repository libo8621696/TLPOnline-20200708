//
//  SettingsTableViewCell.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class SettingsTableViewCell: UITableViewCell {
    
    // MARK: - Internal Property
    
    
    // MARK: - IBOutlet Property
    
    @IBOutlet weak var textCenterLabel: UILabel!
    
    // MARK: - Private Property
    
    
    // MARK: - Internal Methods
    
    class func cell(_ tableView: UITableView, identifier: String) -> SettingsTableViewCell {
        
        return tableView.dequeueReusableCell(withIdentifier: identifier) as! SettingsTableViewCell
    }
    
    // MARK: - Private Methods
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }

}
