//
//  SettingsDetailViewController.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class SettingsDetailViewController: PublicBaseViewController,
                                    UITableViewDelegate, UITableViewDataSource,
                                    UIGestureRecognizerDelegate {
    
    // MARK: - Internal Property
    
    var titleStr: String!
    var settingType: AccountSettingsType = .none
    
    // MARK: - IBOutlet Property
    
    @IBOutlet weak var tableView: UITableView!
    
    // MARK: - Private Property
    
    // View
    var panGesture: UIPanGestureRecognizer = UIPanGestureRecognizer()
    
    // Data
    var showingDatas: [[String: Any]]!
    
    // Language
    var currentSysLanguageType: AppSupportLanguageType?
    var selectNewSysLanguage: String?
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Init View
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        initNavigationBar()
        initShowingDatas()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if self.settingType == .language {
            self.hideHudMain(hud: self.hud)
            enableBackPanGesture()
        }
    }
    
    // MARK: - User Event Handle
    
    // MARK: Click
    
    @objc func cancelButtonDidClick(button: UIButton) {
        
        pushBackVC()
    }
    
    @objc func setButtonDidClick(button: UIBarButtonItem) {
        
        switch self.settingType {
            
            case .language:
                setSysLanguage()
            
            case .changePassword:
                resetPassword()
            
            default:
                break
        }
    }
    
    func settingsItemsDidClick(at indexPath: IndexPath) {
        
        if self.settingType == .language {
            selectLanguage(widthRowAt: indexPath)
        }
    }

    // MARK: - Showing Datas
    
    func initShowingDatas() {
        
        self.showingDatas = SettingsDataSourceService().loadSettingsDetailItemDatas(WithSettingType: self.settingType)
        
        if self.settingType == .language {
            initSysLanguage()
        }
    }
    
    // MARK: - Languages

    func initSysLanguage() {

        if (QLanguageConfig.userLanguage == nil) {
            self.currentSysLanguageType = AppSupportLanguageType.sysDefault
        } else if Bundle.isChineseLanguage() {
            self.currentSysLanguageType = AppSupportLanguageType.zhHans
        } else {
            self.currentSysLanguageType = AppSupportLanguageType.en
        }
    }

    func selectLanguage(widthRowAt indexPath: IndexPath) {

        let languages: [String] = self.showingDatas[indexPath.section]["items"] as! [String]

        for row in 0..<languages.count {

            let indexP = IndexPath(row: row, section: indexPath.section)
            let sCell = self.tableView.cellForRow(at: indexP)
            guard let cell = sCell else { continue }
            cell.accessoryType = .none
        }

        let sCell = self.tableView.cellForRow(at: indexPath)
        guard let cell = sCell else { return }
        cell.accessoryType = .checkmark

        for languageType in AppSupportLanguageType.allValues {

            if languageType.localValue == languages[indexPath.row] {
                self.selectNewSysLanguage = languageType.rawValue
                break
            }
        }
    }

    func setSysLanguage() {

        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Public.setting"), true)

        if self.selectNewSysLanguage == AppSupportLanguageType.sysDefault.rawValue {
            QLanguageConfig.userLanguage = nil
        } else {
            QLanguageConfig.userLanguage = self.selectNewSysLanguage
        }
        
        self.showActionResult(toHud: self.hud, withMessage: Q_LocalizedString("Public.set.success"))

        self.hideHudMain(hud: self.hud)
        self.pushBackVC()
        
        Q_Dispatch_After(0.1, {
            // 更新当前 storyboard
            QLanguageConfig.reload(withStoryboardName: StroyboardType.main.rawValue, selectedIndex: 2)
        })
    }
    
    // MARK: - Reset Password

    func resetPassword() {

        let indexPath = IndexPath(row: 0, section: 0)
        let cell = self.tableView.cellForRow(at: indexPath)
        let newPassword = (cell as! SettingsDetailTableViewCell).valueTextField.text

        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Public.setting"), true)

        AuthenticationLoginDataSourceService()
            .changePassword(withAccount: newPassword,
                success: { (success: Bool, result: [String: Any]?) in

                   self.showActionResult(toHud: self.hud, withMessage: Q_LocalizedString("Public.set.success"))

                   Q_Dispatch_After(1, {

                       self.hideHudMain(hud: self.hud)

                       self.pushBackVC()
                   })

                }) { (error: Error) in


                    switch (error as NSError).code {

                        case RequestResponseCode.responseObjectIsEmpty.rawValue:
                            QF_AlertShow_Note_Main(self, RequestResponseCode.loadDataFailure.localValue)

                        case RequestResponseCode.userNameOrPasswordIsInvalid.rawValue:
                            QF_AlertShow_Note_Main(self, RequestResponseCode.userNameOrPasswordIsInvalid.localValue)
                       
                        default:
                            RequestResponseErrorAlert(error: error,
                                                     target: self,
                                               defaultBlock: {
                                                    QF_AlertShow_Note_Main(self, RequestResponseCode.loginFailure.localValue)
                                               })
                   }
               }
    }

    // MARK: - Navigation Bar
    
    func initNavigationBar() {
        
        if self.settingType == .language {
            initBackPanGesture()
        }
        
        setNavigationBarTitle()
        setNavigationBarLeftButton()
        setNavigationBarRightButton()
    }
    
    func setNavigationBarTitle() {
        
        Q_NavigationItemTitleSet(self, titleStr)
    }
    
    func setNavigationBarLeftButton() {
        
        Q_NavigationItemLeftTitleButtonSet(self,
                                           Q_LocalizedString("Public.cancel"),
                                           #selector(cancelButtonDidClick(button:)))
    }
    
    func setNavigationBarRightButton() {
        
        Q_NavigationItemRightTitleButtonSet(self,
                                            Q_LocalizedString("Public.done"),
                                            #selector(setButtonDidClick(button:)))
    }
    
    // MARK: - Table View

    // MARK: UITableViewDataSource, UITableViewDelegate

    func numberOfSections(in tableView: UITableView) -> Int {

        let items: [[String: Any]] = self.showingDatas
        return items.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        let items: [String] = self.showingDatas[section]["items"] as! [String]
        return items.count
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

        return 44
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {

        return 32
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        var cell = UITableViewCell()

        switch self.settingType {

            case .language:
                cell = SettingsDetailTableViewCell.cell(tableView, identifier: "settingsDetailItemSetCell")
                cell.textLabel?.text = (self.showingDatas[indexPath.section]["items"] as! [String])[indexPath.row]
                if self.currentSysLanguageType?.localValue == cell.textLabel?.text {
                    cell.accessoryType = .checkmark
                } else {
                    cell.accessoryType = .none
                }
                cell.selectionStyle = .none
            
            case .changePassword:
                cell = SettingsDetailTableViewCell.cell(tableView, identifier: "settingsDetailItemInputSetCell")
                cell.textLabel?.text = (self.showingDatas[indexPath.section]["items"] as! [String])[indexPath.row]
                (cell as! SettingsDetailTableViewCell).valueTextField.isSecureTextEntry = true
                (cell as! SettingsDetailTableViewCell).valueTextField.becomeFirstResponder()
                cell.accessoryType = .none
                cell.selectionStyle = .none

            default:
                break
        }

        return cell
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {

        return nil
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        tableView.deselectRow(at: indexPath, animated: true)
        settingsItemsDidClick(at: indexPath)
    }
    
    // MARK: - Back Pan Gesture
    
    func initBackPanGesture() {
        
        disableBackPanGesture()
    }
    
    func enableBackPanGesture() {
        
        QM_NAVIGATION_BACK_GESTURE_ENABLE(self, self.panGesture)
    }
    
    func disableBackPanGesture() {
        
        self.panGesture = QM_NAVIGATION_BACK_GESTURE_DISABLE(self)
    }
    
    // MARK: - Navigation
    
    func pushBackVC() {
        
        Q_PopViewController(self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
    }

}
