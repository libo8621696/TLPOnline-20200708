//
//  SettingsModel.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class SettingsModel: NSObject {
    
    // MARK: - Internal Property
    
    let settingItems: [[String: Any]] = {
        
        let general: [String: Any] = [
            "title": AccountSettingsType.general.localValue,
            "code": "general",
            "items": [
                AccountSettingsType.language.localValue,
                AccountSettingsType.changePassword.localValue
            ]
        ]
        
        let logout: [String: Any] = [
            "title": AccountSettingsType.logOut.localValue,
            "code": "logout",
            "items": [
                AccountSettingsType.logOut.localValue
            ]
        ]
        
        var items = [[String: Any]]()
        
        items = [
            general,
            logout
        ]
        
        return items
    }()

}
