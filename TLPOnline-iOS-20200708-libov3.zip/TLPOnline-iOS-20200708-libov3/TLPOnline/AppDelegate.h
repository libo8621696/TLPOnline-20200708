//
//  AppDelegate.h
//  UUID
//
//  Created by ThomasYang on 16/6/28.
//  Copyright © 2016年 yunzujia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

