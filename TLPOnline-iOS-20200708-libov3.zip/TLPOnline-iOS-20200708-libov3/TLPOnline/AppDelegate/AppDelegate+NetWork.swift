//
//  AppDelegate+NetWork.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

extension AppDelegate {
    
    // MARK: - NetWork
    
    func initNetWorkMonitor() {
        QM_AFN_NET_MONITOR_NOTIFICATION_START()
    }
    
}
