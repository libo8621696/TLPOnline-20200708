//
//  AppDelegate+Keyboard.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

extension AppDelegate {
    
    // MARK: - Keyboard
    
    func initIQKeyboard() {
        
        let manager: IQKeyboardManager = IQKeyboardManager.shared()
        manager.isEnabled = true;
        manager.shouldResignOnTouchOutside = true;
        manager.toolbarDoneBarButtonItemText = AppDelegateLocalizable.done.localValue;
    }
    
}
