//
//  AppDelegate+Localizable.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

// MARK: - App Delegate Localizable

enum AppDelegateLocalizable: String {
    
    case now
    
    case warning
    case ok
    case done
}

extension AppDelegateLocalizable {
    
    var localValue: String {
        
        switch self {
            
            case .now:
                return Q_LocalizedString("Public.now")
            
            case .warning:
                return Q_LocalizedString("Public.warning")
            
            case .ok:
                return Q_LocalizedString("Public.ok")
            
            case .done:
                return Q_LocalizedString("Public.done")
        }
    }
}
