//
//  MsgAlertDefinition+Localizable.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

extension QAlertTitle {
    
    var localValue: String {
        
        switch self {
            
            case .titleNone:
                return Q_LocalizedString("Public.none")
            
            case .titleWarning:
                return Q_LocalizedString("Public.warning")
            
            case .titleNote:
                return Q_LocalizedString("Public.note")
            
            case .titleMessage:
                return Q_LocalizedString("Public.message")
            
            case .titlePrompt:
                return Q_LocalizedString("Public.prompt")
        }
    }
}

extension QAlertButtonTitle {
    
    var localValue: String {
        
        switch self {
            
            case .titleOK:
                return Q_LocalizedString("Public.ok")
            
            case .titleNO:
                return Q_LocalizedString("Public.no")
        }
    }
}
