//
//  Configuration.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

/// API URL

let API_ROOT_DEFAULT_URL        = "http://115.28.186.121:5677"


/// Token

let ACCESS_TOKEN_EXPIRE_TIME = 60 * 60
