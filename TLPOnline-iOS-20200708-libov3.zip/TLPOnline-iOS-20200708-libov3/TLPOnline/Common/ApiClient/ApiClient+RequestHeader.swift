//
//  ApiClient+RequestHeader.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

extension ApiClient {
    
    // MARK: - Base Request Header
    
    class func AuthorizationHeader() -> [String: String]? {
        
        if UserSession.CurrentSession().hasValidAccessToken == false {
            return nil
        }
        
        guard let accessToken = UserSession.CurrentSession().userAccessTokenModel?.Ticket else {
            return nil
        }
        
        let header: [String: String] = [
            "Authorization": "Basic " + accessToken
        ]

        return header
    }
    
    // MARK: - App Type Request Header
    
    class func AuthorizationAppTypeHeader() -> [String: String]? {
        
        let header: [String: String] = [
            :
        ]
        
        return header
    }
    
}
