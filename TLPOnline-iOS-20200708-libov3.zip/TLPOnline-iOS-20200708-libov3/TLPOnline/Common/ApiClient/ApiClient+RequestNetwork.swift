//
//  ApiClient+Network+Service.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

extension ApiClient {
    
    // MARK: - Network Lost Status
    
    func validateNetworkLostStatus(successBlock: ((_ response: URLResponse, _ responseData: [String: Any]?) -> Void)?,
                                   failureBlock: ((_ error: Error?) -> Void)?) -> Bool {
        
        // 检测网络状态
        let (isNetLost, netLostError) = RequestResponseNetworkLinkLostValidate()
        
        if isNetLost == true {
            
            if failureBlock != nil {
                failureBlock!(netLostError!)
            }
            return true
        }
        
        return false
    }
    
    func validateNetworkLostStatus(successBlock: ((_ urlResponse: URLResponse, _ url: URL?) -> Void)?,
                                   failureBlock: ((_ error: Error?) -> Void)?) -> Bool {
        
        // 检测网络状态
        let (isNetLost, netLostError) = RequestResponseNetworkLinkLostValidate()
        
        if isNetLost == true {
            
            if failureBlock != nil {
                failureBlock!(netLostError!)
            }
            return true
        }
        
        return false
    }
    
}
