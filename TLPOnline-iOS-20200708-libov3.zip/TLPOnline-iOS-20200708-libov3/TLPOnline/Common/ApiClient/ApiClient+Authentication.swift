//
//  ApiClient+Authentication.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

extension ApiClient {
    
    // MARK: - Internal Methods
    
    func login(account: String!,
              password: String!,
              uuid:String!,
              validationcode:String!,
              success successBlock: ((_ result: [String : Any]?) -> Void)?,
              failure failureBlock: ((_ error: Error?) -> Void)?) {
        
        let params: NSDictionary = [
                                    "username": account,
                                    "password": password,
                                     "uuid": uuid,
                                     "validationcode": validationcode,
                                  ]
        
        self.sendRequest(urlPath: API_AUTH_LOGIN_URL_PATH,
                   requestMethod: .post,
                  requestHeaders: ApiClient.AuthorizationAppTypeHeader(),
               requestParameters: params,
             uploadProgressBlock: nil,
           downloadProgressBlock: nil,
                    successBlock: { (response: URLResponse?, responseData: [String : Any]?) in

                        if successBlock != nil {
                            successBlock!(responseData)
                        }
                        
                     }) { (error: Error?) in

                        if failureBlock != nil {
                            failureBlock!(error)
                        }
                     }
    }
    
    func logout(success successBlock: ((_ result: [String : Any]?) -> Void)?,
                failure failureBlock: ((_ error: Error?) -> Void)?) {
        
        self.sendRequest(urlPath: API_AUTH_LOGOUT_URL_PATH,
                   requestMethod: .post,
                  requestHeaders: ApiClient.AuthorizationHeader(),
               requestParameters: nil,
             uploadProgressBlock: nil,
           downloadProgressBlock: nil,
                    successBlock: { (response: URLResponse?, responseData: [String : Any]?) in
                    
                        if successBlock != nil {
                            successBlock!(responseData)
                        }
                    
                     }) { (error: Error?) in
                    
                        if failureBlock != nil {
                            failureBlock!(error)
                        }
                     }
    }

    func changePassword(password: String!,
            success successBlock: ((_ result: [String : Any]?) -> Void)?,
            failure failureBlock: ((_ error: Error?) -> Void)?) {

        self.sendRequest(urlPath: API_AUTH_PASSWORD_URL_PATH,
                   requestMethod: .post,
                  requestHeaders: ApiClient.AuthorizationHeader(),
               requestParameters: password,
             uploadProgressBlock: nil,
           downloadProgressBlock: nil,
                    successBlock: { (response: URLResponse?, responseData: [String : Any]?) in

                        if successBlock != nil {
                            successBlock!(responseData)
                        }

                     }) { (error: Error?) in

                        if failureBlock != nil {
                            failureBlock!(error)
                        }
                     }
    }
    
}
