//
//  ApiClient+RequestResponse.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation


// MARK: - Request Response Error Domain

enum RequestResponseErrorDomain: String {
    
    case networkLinkError
    case apiReceivedError
}

// MARK: - Request Response Code

enum RequestResponseCode: Int {

    case requestTimedOut                                = -1001
    case serverHostnameCouldNotBeFound                  = -1003

    case networkLinkSuccess                             = 1003
    case networkLinkFailure                             = 10041
    case networkLinkLost                                = 1005

    case successed                                      = 200
    case responseObjectIsEmpty                          = 204
    case unauthorized                                   = 1019
    case pageUnfound                                    = 404
    case serverError                                    = 3840

    case invalidRequestParam                            = 9000
    
    case userNameOrPasswordIsInvalid                    = 1015
    case CaptchaIsInvalid                               = 1022
    case unauthorizedCaptcha                            = 1021
    case wrongPasswordOverThreeTimes                    = 1020
    case userNotExist                                   = 1004

    case loginFailure                                   = 1006
    case logoutFailure                                  = 40114
    case verifyFailure                                  = 40115

    case loadDataFailure                                = 40105
    

    
}


// MARK: - Request Response Error

let RequestResponseNetworkLinkLostError                 = NSError(domain: RequestResponseErrorDomain.networkLinkError.localValue,
                                                                    code: RequestResponseCode.networkLinkLost.rawValue,
                                                                userInfo: ["code"   : RequestResponseCode.networkLinkLost.rawValue,
                                                                           "message": RequestResponseCode.networkLinkLost.localValue])

let RequestResponseObjectIsEmptyError                   = NSError(domain: RequestResponseErrorDomain.apiReceivedError.localValue,
                                                                    code: RequestResponseCode.responseObjectIsEmpty.rawValue,
                                                                userInfo: ["code"   : RequestResponseCode.responseObjectIsEmpty.rawValue,
                                                                           "message": RequestResponseCode.responseObjectIsEmpty.localValue])

func RequestResponseObjectError(_ responseObject: Any?) -> NSError {
    
    return NSError(domain: (responseObject as! Dictionary<AnyHashable, Any>)["code"] as! String,
                     code: (responseObject as! Dictionary<AnyHashable, Any>)["errno"] as! Int,
                 userInfo: ["code"   : (responseObject as! Dictionary<AnyHashable, Any>)["errno"] as! Int,
                            "message": (responseObject as! Dictionary<AnyHashable, Any>)["code"] as! String])
}

func RequestResponseObjectReceivedError(_ responseObject: Any?) -> NSError {
    
    return NSError(domain: RequestResponseErrorDomain.apiReceivedError.localValue,
                     code: ((responseObject as! [String: Any])["code"] as! Int),
                 userInfo: ["code"   : ((responseObject as! [String: Any])["code"] as! Int),
                            "message": responseObject as? [String : Any] ?? ""])
}

// MARK: - Request Response Error Alert

func RequestResponseErrorAlert(error: Error,
                              target: UIViewController,
                        defaultBlock: (() -> Void)?) {

    switch (error as NSError).code {
        
        case RequestResponseCode.requestTimedOut.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.requestTimedOut.localValue)
        
        case RequestResponseCode.serverHostnameCouldNotBeFound.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.serverHostnameCouldNotBeFound.localValue)
        
        case RequestResponseCode.networkLinkSuccess.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.networkLinkSuccess.localValue)
        
        case RequestResponseCode.networkLinkFailure.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.networkLinkFailure.localValue)
        
        case RequestResponseCode.networkLinkLost.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.networkLinkLost.localValue)
    
        case RequestResponseCode.successed.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.successed.localValue)
        
        case RequestResponseCode.responseObjectIsEmpty.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.responseObjectIsEmpty.localValue)

        case RequestResponseCode.unauthorized.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.unauthorized.localValue) {         // access token 过期
                Q_NotificationPost(USER_TOKEN_AUTHENTICATION_FAILURE_NOTIFICATION, nil)
                AuthenticationLogoutDataSourceService().clearLocalCacheDatas()
            }
        
        case RequestResponseCode.pageUnfound.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.pageUnfound.localValue)
            
        case RequestResponseCode.serverError.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.serverError.localValue)

        case RequestResponseCode.invalidRequestParam.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.invalidRequestParam.localValue)

        case RequestResponseCode.userNameOrPasswordIsInvalid.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.userNameOrPasswordIsInvalid.localValue)
        
        case RequestResponseCode.CaptchaIsInvalid.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.CaptchaIsInvalid.localValue)
        
        case RequestResponseCode.unauthorizedCaptcha.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.unauthorizedCaptcha.localValue)
        
        case RequestResponseCode.wrongPasswordOverThreeTimes.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.wrongPasswordOverThreeTimes.localValue)

        case RequestResponseCode.userNotExist.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.userNotExist.localValue)

        case RequestResponseCode.loginFailure.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.loginFailure.localValue)
        
        case RequestResponseCode.logoutFailure.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.logoutFailure.localValue)
        
        case RequestResponseCode.verifyFailure.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.verifyFailure.localValue)
        
        case RequestResponseCode.loadDataFailure.rawValue:
            QF_AlertShow_Note_Main(target, RequestResponseCode.loadDataFailure.localValue)
        
        default:
            if defaultBlock == nil {
                QF_AlertShow_Note_Main(target, RequestResponseCode.loadDataFailure.localValue)
            } else {
                defaultBlock!()
            }
    }
}

// MARK: - Request Response Validate

// Network Link Lost
func RequestResponseNetworkLinkLostValidate() -> (isLost: Bool, error: Error?) {

    if QM_AFN_NET_IS_REACHABLE() == false {
        return (true, RequestResponseNetworkLinkLostError)
    }
    return (false, nil)
}

// Error Null Object
func RequestResponseErrorNullObjectValidate(error: Error?) -> Error {
    
    if error == nil {
        return RequestResponseObjectIsEmptyError
    }
    return error!
}

// Result Array Object
func RequestResponseResultArrayObjectEmptyValidate(result: [String : Any]?) -> (isEmpty: Bool, error: Error?) {

    if result == nil                             ||
       result!["result"] is NSNull               ||
       result!["result"] == nil                  ||
       (result!["result"] as? [Any])?.count == 0 {

        return (true, RequestResponseObjectIsEmptyError)
    }
    return (false, nil)
}

// Result Array Object
func RequestResponseResultArrayObjectEmptyValidate(result: [String : Any]?, key: String) -> (isEmpty: Bool, error: Error?) {
    
    if result == nil                                                      ||
       result!["result"] is NSNull                                        ||
       result!["result"] == nil                                           ||
       ((result!["result"] as! [String: Any])[key] as? [Any])?.count == 0 {
        
        return (true, RequestResponseObjectIsEmptyError)
    }
    return (false, nil)
}

// Result Dictonary Object
func RequestResponseResultDictonaryObjectEmptyValidate(result: [String : Any]?) -> (isEmpty: Bool, error: Error?) {
    
    if result == nil                                     ||
       result!["result"] is NSNull                       ||
       result!["result"] == nil                          ||
       (result!["result"] as? [String: Any])?.count == 0 {
        
        return (true, RequestResponseObjectIsEmptyError)
    }
    return (false, nil)
}

// Result Bool Object
func RequestResponseResultBoolObjectValidate(result: [String : Any]?) -> (isEmpty: Bool, error: Error?) {

    if result == nil                     ||
       result!["result"] is NSNull       ||
       result!["result"] == nil          ||
       result!["result"] as? Bool == nil {

        return (true, RequestResponseObjectIsEmptyError)
    }
    return (false, nil)
}

// Result Int Object
func RequestResponseResultIntObjectValidate(result: [String : Any]?) -> (isEmpty: Bool, error: Error?) {
    
    if result == nil                    ||
       result!["result"] is NSNull      ||
       result!["result"] == nil         ||
       result!["result"] as? Int == nil {
        
        return (true, RequestResponseObjectIsEmptyError)
    }
    return (false, nil)
}

// Result Null Object
func RequestResponseResultNullObjectValidate(result: [String : Any]?) -> (isEmpty: Bool, error: Error?) {
    
    if result == nil               ||
       result!["result"] is NSNull ||
       result!["result"] == nil    {
        
        return (true, RequestResponseObjectIsEmptyError)
    }
    return (false, nil)
}
