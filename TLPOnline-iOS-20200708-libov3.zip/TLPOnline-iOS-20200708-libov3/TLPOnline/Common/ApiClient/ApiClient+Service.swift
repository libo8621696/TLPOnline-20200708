//
//  ApiClient+Service.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

extension ApiClient {
    
    // MARK: - Internal Methods
    
    
    
    // MARK: Load Airport

    func retrieveAirportData(success successBlock: ((_ result: [String : Any]?) -> Void)?,
                             failure failureBlock: ((_ error: Error?) -> Void)?) {
        
        self.sendRequest(urlPath: API_AIRPORT_URL_PATH,
                   requestMethod: .get,
                  requestHeaders: ApiClient.AuthorizationHeader(),
               requestParameters: nil,
             uploadProgressBlock: nil,
           downloadProgressBlock: nil,
                    successBlock: { (response: URLResponse?, responseData: [String : Any]?) in
            
                        if successBlock != nil {
                            successBlock!(responseData)
                        }
            
                    }) { (error: Error?) in
            
                        if failureBlock != nil {
                            failureBlock!(error)
                        }
                    }
    }
    
    // MARK: Load Runway

    func retrieveRunwayData(withAirportCode airportCode: String,
                                   success successBlock: ((_ result: [String : Any]?) -> Void)?,
                                   failure failureBlock: ((_ error: Error?) -> Void)?) {
        
        self.sendRequest(urlPath: API_RUNWAY_URL_PATH + "/\(airportCode)/runways",
                   requestMethod: .get,
                  requestHeaders: ApiClient.AuthorizationHeader(),
               requestParameters: nil,
             uploadProgressBlock: nil,
           downloadProgressBlock: nil,
                    successBlock: { (response: URLResponse?, responseData: [String : Any]?) in
            
                        if successBlock != nil {
                            successBlock!(responseData)
                        }
            
                    }) { (error: Error?) in
            
                        if failureBlock != nil {
                            failureBlock!(error)
                        }
                    }
    }
    
    // MARK: Calculate

    func calculatePerformanceData(withCalculateType calculateType: CalculateType,
                                              calculateParamDatas: CalculateParamModel,
                                             success successBlock: ((_ result: [String : Any]?) -> Void)?,
                                             failure failureBlock: ((_ error: Error?) -> Void)?) {

        var params: [String : Any?] = [:]
        var urlPath: String = ""
        
        switch calculateType {

            case .takeoff:
                urlPath = API_TAKEOFF_CALCULATE_URL_PATH
                params = [
                    "ICAOCode"    : calculateParamDatas.airport,
                    "Designation" : calculateParamDatas.runway,
                    "OAT"         : calculateParamDatas.oat,
                    "QNH"         : calculateParamDatas.qnh,
                    "Wind"        : calculateParamDatas.wind,
                    "RWCondition" : calculateParamDatas.rwCondition,
                    "TakeoffW"    : calculateParamDatas.takeoffW,
                    "AntiIce"     : calculateParamDatas.antiIce
                ]
                if UserSession.CurrentSession().takeoffCDLDatas != nil {
                    params["SPIB"] = UserSession.CurrentSession().takeoffCDLDatas!
                }

            case .landing:
                urlPath = API_LANDING_CALCULATE_URL_PATH
                params = [
                    "ICAOCode"    : calculateParamDatas.airport,
                    "Designation" : calculateParamDatas.runway,
                    "OAT"         : calculateParamDatas.oat,
                    "QNH"         : calculateParamDatas.qnh,
                    "Wind"        : calculateParamDatas.wind,
                    "RWCondition" : calculateParamDatas.rwCondition,
                    "Ldg_Conf"    : calculateParamDatas.ldgConf,
                    "BrakeMode"   : calculateParamDatas.brakeMode,
                    "Reversers"   : calculateParamDatas.reversers
                ]
                if UserSession.CurrentSession().landingCDLDatas != nil {
                    params["SPIBL"] = UserSession.CurrentSession().landingCDLDatas!
                }
            
            default:
                return
        }
        
        self.sendRequest(urlPath: urlPath,
                   requestMethod: .post,
                  requestHeaders: ApiClient.AuthorizationHeader(),
               requestParameters: params,
             uploadProgressBlock: nil,
           downloadProgressBlock: nil,
                    successBlock: { (response: URLResponse?, responseData: [String : Any]?) in

                        if successBlock != nil {
                            successBlock!(responseData)
                        }

                    }) { (error: Error?) in

                        if failureBlock != nil {
                            failureBlock!(error)
                        }
                    }
    }
    
}
