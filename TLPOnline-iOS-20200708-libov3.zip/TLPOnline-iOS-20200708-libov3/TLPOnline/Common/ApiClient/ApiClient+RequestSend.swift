//
//  ApiClient+Request.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

import SwiftyJSON

extension ApiClient {

    // MARK: - Create Base Net Request

    func sendRequest(urlPath url: String,
            requestMethod method: RequestMethod,
          requestHeaders headers: [String: String]?,
        requestParameters data: Any?,
             uploadProgressBlock: ((_ uploadProgress: Progress?) -> Void)?,
           downloadProgressBlock: ((_ downloadProgress: Progress?) -> Void)?,
                    successBlock: ((_ response: URLResponse, _ responseData: [String: Any]?) -> Void)?,
                    failureBlock: ((_ error: Error?) -> Void)?) {

        let isNetLost = validateNetworkLostStatus(successBlock: successBlock, failureBlock: failureBlock)
        if isNetLost == true {
            return
        }

        let urlStr = url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        let absoluteURL: URL = URL(string: urlStr!, relativeTo: self.manager.baseURL)!

        let serializer: AFJSONRequestSerializer = AFJSONRequestSerializer()
        if headers != nil {
            for key in Array(headers!.keys) {
                serializer.setValue(headers![key], forHTTPHeaderField: key)
            }
        }

        let err: Error? = nil
        
        
        
        
        let request: URLRequest = serializer.request(withMethod: method.rawValue,
                                                      urlString: absoluteURL.absoluteString,
                                                     parameters: data,
                                                          error: err as? AutoreleasingUnsafeMutablePointer<NSError?>) as URLRequest
        if err != nil {

            LOG("Serializing Request Error",
                "Request URL    : \(String(describing: absoluteURL))",
                "Request Headers: \(String(describing: headers))",
                "Request Method : \(method.rawValue)",
                "",
                "Request Params : \(String(describing: data))",
                "",
                "Response Object: \(String(describing: err))")

            return
        }

        self.manager.dataTask(with: request,
            uploadProgress: { (uploadProgress: Progress) in

                if uploadProgressBlock != nil {
                    uploadProgressBlock!(uploadProgress)
                }

            }, downloadProgress: { (downloadProgress: Progress) in

                if downloadProgressBlock != nil {
                    downloadProgressBlock!(downloadProgress)
                }

            }) { (response: URLResponse, responseObject: Any?, error: Error?) in

                //LOG("Sending Request response",
                //    "\(response)",
                //    "\((response as! HTTPURLResponse).statusCode)",
                //    "\(responseObject.debugDescription)")

                /// Error

                if error != nil {
                    
                    let error_info = (error as! NSError).userInfo
                    
                    let error_string = error_info["com.alamofire.serialization.response.error.string"]
                    
                    let error_json = JSON(error_string)
                    
//                    let str = "\(error_json)"
//
//                    let index2 = str.index(str.startIndex, offsetBy: 8)
//                    let index3 = str.index(str.startIndex, offsetBy: 11)
//                    let code = Int(str[index2...index3])!
//                    
//                    print(code)

                    LOG("Sending Request Error",
                        "Request URL    : \(String(describing: request.url!))",
                        "Request Headers: \(String(describing: headers))",
                        "Request Method : \(method.rawValue)",
                        "",
                        "Request Params : \(String(describing: data))",
                        "",
                        "Response Object: \(String(describing: error))")

                    if failureBlock != nil {
                        failureBlock!(error)
                    }
                    return
                }

                /// Response Object

                LOG("Sending Request Success",
                    "Request URL    : \(String(describing: request.url!))",
                    "Request Headers: \(String(describing: headers))",
                    "Request Method : \(method.rawValue)",
                    "",
                    "Request Params : \(String(describing: data))",
                    "",
                    "response       : \(String(describing: response))",
                    "",
                    "Response Object: \(String(describing: responseObject))")

                if (responseObject != nil) && !(responseObject is Dictionary<AnyHashable, Any>) {

                    if (responseObject as! Array<Any>).count == 0 {

                        if failureBlock != nil {
                            failureBlock!(RequestResponseObjectIsEmptyError)
                        }
                        return
                    }
                    
                    if successBlock != nil {
                        successBlock!(response, ["result": responseObject!])
                    }
                    return
                }

                if (responseObject != nil) && (responseObject as! Dictionary<AnyHashable, Any>).count == 0 {

                    if failureBlock != nil {
                        failureBlock!(RequestResponseObjectIsEmptyError)
                    }
                    return
                }

                if (responseObject != nil) {
                    if successBlock != nil {
                        successBlock!(response, ["result": responseObject!])
                    }
                } else {
                    if successBlock != nil {
                        successBlock!(response, nil)
                    }
                }
                
                
            }.resume()
    }

    // MARK: - Cancel Net Request
    
    func cancelAllRequestOperations() {
        
        for task in self.manager.dataTasks {
            task.cancel()
        }
    }

}
