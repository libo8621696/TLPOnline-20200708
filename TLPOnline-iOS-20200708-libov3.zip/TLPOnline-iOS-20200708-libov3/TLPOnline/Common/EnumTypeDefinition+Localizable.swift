//
//  EnumTypeDefinition+Localizable.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation


// MARK: - App Support Language Type

extension AppSupportLanguageType {
    
    var localValue: String {
        
        switch self {
            
            case .sysDefault:
                return Q_LocalizedString("Public.language.sysDefault")
            
            case .en:
                return Q_LocalizedString("Public.language.en")
            
            case .zhHans:
                return Q_LocalizedString("Public.language.zhHans")
        }
    }
}

// MARK: - Change Password Type

extension ChangePasswordType {
    
    var localValue: String {
        
        switch self {
            
            case .newPassword:
                return Q_LocalizedString("Public.changePassword.newPassword")
        }
    }
}

// MARK: - Auth Verify Msg Type

extension AuthVerifyMsgType {
    
    var localValue: String {
        
        switch self {
            
            case .serverAddress:
                return Q_LocalizedString("Auth.verifyMsg.serverAddress")
            
            case .account:
                return Q_LocalizedString("Auth.verifyMsg.account")
            
            case .password:
                return Q_LocalizedString("Auth.verifyMsg.password")
            
            case .uuid:
                return Q_LocalizedString("Auth.verifyMsg.uuid")
            
            case .code:
                return Q_LocalizedString("Auth.verifyMsg.code")

            case .airport:
                return Q_LocalizedString("Auth.verifyMsg.airport")

            case .runway:
                return Q_LocalizedString("Auth.verifyMsg.runway")

            case .rwCondition:
                return Q_LocalizedString("Auth.verifyMsg.rwCondition")

            case .antiIce:
                return Q_LocalizedString("Auth.verifyMsg.antiIce")

            case .ldgConf:
                return Q_LocalizedString("Auth.verifyMsg.ldgConf")

            case .breakMode:
                return Q_LocalizedString("Auth.verifyMsg.breakMode")

            case .reversers:
                return Q_LocalizedString("Auth.verifyMsg.reversers")

            case .oat:
                return Q_LocalizedString("Auth.verifyMsg.oat")

            case .qnh:
                return Q_LocalizedString("Auth.verifyMsg.qnh")

            case .wind:
                return Q_LocalizedString("Auth.verifyMsg.wind")

            case .takeoffW:
                return Q_LocalizedString("Auth.verifyMsg.takeoffW")
        }
    }
}

// MARK: - Account Settings Type

extension AccountSettingsType {
    
    var localValue: String {
        
        switch self {
            
            case .none:
                return Q_LocalizedString("Setting.none")
            
            case .general:
                return Q_LocalizedString("Setting.general")
            
            case .language:
                return Q_LocalizedString("Setting.language")
            
            case .changePassword:
                return Q_LocalizedString("Setting.changePassword")
                
            case .logOut:
                return Q_LocalizedString("Setting.logout")
        }
    }
    
    init?(localValue: String) {
        
        switch localValue {
            
            case AccountSettingsType.none.localValue:
                self = .none
            
            case AccountSettingsType.general.localValue:
                self = .general
            
            case AccountSettingsType.language.localValue:
                self = .language
            
            case AccountSettingsType.changePassword.localValue:
                self = .changePassword
            
            case AccountSettingsType.logOut.localValue:
                self = .logOut
            
            default:
                return nil
        }
    }
}
