//
//  Configuration+Definition.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import Foundation

/// Standard Color

let COLOR_MAIN                                      = Q_HexColor("#4D7ABD")

/// Notification Key

let USER_LOGIN_AUTHENTICATION_SUCCESS_NOTIFICATION  = "USER_LOGIN_AUTHENTICATION_SUCCESS_NOTIFICATION"
let USER_LOGOUT_AUTHENTICATION_SUCCESS_NOTIFICATION = "USER_LOGOUT_AUTHENTICATION_SUCCESS_NOTIFICATION"
let USER_TOKEN_AUTHENTICATION_SUCCESS_NOTIFICATION  = "USER_TOKEN_AUTHENTICATION_SUCCESS_NOTIFICATION"
let USER_TOKEN_AUTHENTICATION_FAILURE_NOTIFICATION  = "USER_TOKEN_AUTHENTICATION_FAILURE_NOTIFICATION"

/// Definition Key

let APP_LANGUAGES_KEY                               = "AppleLanguages"
let APP_LANGUAGES_USER_KEY                          = "AppleLanguagesUser"

let USER_ACCESS_TOKEN_SESSION_KEY                   = "TLP_ONLINE_USER_ACCESS_TOKEN"

let API_ROOT_URL_KEY                                = "API_ROOT_URL"
let USER_LOGIN_NAME_KEY                             = "USER_LOGIN_NAME"
