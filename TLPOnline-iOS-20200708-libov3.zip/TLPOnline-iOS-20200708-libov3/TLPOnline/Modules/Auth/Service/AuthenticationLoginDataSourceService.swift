//
//  AuthenticationLoginDataSourceService.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class AuthenticationLoginDataSourceService: NSObject {
    
    // MARK: - Private Property
    
    private var account: String!
    private var password: String!
    private var uuid:String!
    private var password_changed:String!
    private var validationcode:String!
    private var successBlock: ((_ success: Bool, _ result: [String: Any]?) -> Void)?
    private var failureBlock: ((_ error: Error) -> Void)?
    
    // MARK: - Internal Methods
    
    // MARK: Change Password
    
    func changePassword(withAccount password_changed: String?,
                                success successBlock: ((_ success: Bool, _ result: [String: Any]?) -> Void)?,
                                failure failureBlock: ((_ error: Error) -> Void)?) {
        
        self.password_changed = password_changed ?? ""
        
        self.successBlock = successBlock
        self.failureBlock = failureBlock
        
        ApiClient.DefaultClient()
            .changePassword(
                  password: password_changed,
            success: { (result: [String : Any]?) in

                if self.successBlock != nil {
                    self.successBlock!(true, nil)
                }
                
            }, failure: { (error: Error?) in
                
                let err = RequestResponseErrorNullObjectValidate(error: error)
                self.userLoginFailureAction(withError: err)
            })
    }
    
    // MARK: Login
    
    func userLogin(withAccount account: String?,
                              password: String?,
                                  uuid: String?,
                                  validationcode: String?,
                  success successBlock: ((_ success: Bool, _ result: [String: Any]?) -> Void)?,
                  failure failureBlock: ((_ error: Error) -> Void)?) {
        
        self.account = account ?? ""
        self.password = password ?? ""
        self.uuid = uuid ?? ""
        
        self.validationcode = validationcode ?? ""
        self.password_changed = password_changed ?? ""
        
        self.successBlock = successBlock
        self.failureBlock = failureBlock
        
    
        
        ApiClient.DefaultClient()
            .login(account: account,
                  password: password,
                  uuid: uuid,
                  validationcode: validationcode,
            success: { (result: [String : Any]?) in
                
                let (isEmpty, error) = RequestResponseResultDictonaryObjectEmptyValidate(result: result)
                if isEmpty == true {
                    self.userLoginFailureAction(withError: error!)
                    return
                }
                
                var rst: [String: Any] = result!["result"] as! [String : Any]
                
                rst["expireAtDateTime"] = "\(Date(timeIntervalSinceNow: TimeInterval(ACCESS_TOKEN_EXPIRE_TIME)))"
                
                self.userLoginSuccessAction(withResult: rst)
                
            }, failure: { (error: Error?) in
                
                let err = RequestResponseErrorNullObjectValidate(error: error)
                self.userLoginFailureAction(withError: err)
            })
    }
    
    // MARK: Login Action
    
    private func userLoginSuccessAction(withResult result: [String: Any]) {
        
        let loginUserName: String = self.account
        
        // 保存登录成功数据
        UserSession.CurrentSession().overrideUserAccessToken(session: result)
        
        // 保存登录用户名
        AuthenticationSecurityService().saveLocalUserLogin(userName: loginUserName)
        
        if self.successBlock != nil {
            self.successBlock!(true, nil)
        }
    }
    
    private func userLoginFailureAction(withError error: Error) {
        
        if self.failureBlock != nil {
            self.failureBlock!(error)
        }
    }
    
}
