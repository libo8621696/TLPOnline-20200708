//
//  AuthenticationVerifyService.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit


// MARK: Verify

func ServerAddressIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 &&
       value!.q_isValidUrlAddress() {
        
        return true
    }
    return false
}

func AccountIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}

func PasswordIsValid(_ value: String?) -> Bool {
    
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}

func UUIDIsValid(_ value: String?) -> Bool {
    let InstaransObject:MAC = MAC()
    
    let UUIDinfo = InstaransObject.getUUID()
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}

func CodeIsValid(_ value: String?) -> Bool {
    if value != nil &&
       value!.q_length() > 0 {
        
        return true
    }
    return false
}


