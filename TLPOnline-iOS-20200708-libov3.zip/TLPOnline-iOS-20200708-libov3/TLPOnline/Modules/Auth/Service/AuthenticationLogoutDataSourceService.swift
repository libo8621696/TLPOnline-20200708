//
//  AuthenticationLogoutDataSourceService.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class AuthenticationLogoutDataSourceService: NSObject {

    // MARK: - Private Property
    
    private var successBlock: ((_ success: Bool, _ result: [String: Any]?) -> Void)?
    private var failureBlock: ((_ error: Error) -> Void)?
    
    // MARK: - Internal Methods

    // MARK: Logout
    
    func userLogout(success successBlock: ((_ success: Bool, _ result: [String: Any]?) -> Void)?,
                    failure failureBlock: ((_ error: Error) -> Void)?) {
        
        self.successBlock = successBlock
        self.failureBlock = failureBlock
        
        clearLocalCacheDatas()
        
        self.userLogoutSuccessAction(withResult: [:])
    }
    
    // MARK: Logout Action
    
    private func userLogoutSuccessAction(withResult result: [String: Any]) {
        
        if self.successBlock != nil {
            self.successBlock!(true, nil)
        }
    }
    
    private func userLogoutFailureAction(withError error: Error) {
        
        if self.failureBlock != nil {
            self.failureBlock!(error)
        }
    }
    
    // MARK: Local Cache

    func clearLocalCacheDatas() {

        // 清除用户本地偏好设置
        UserSession.CurrentSession().removeUserSession()
    }
    
}
