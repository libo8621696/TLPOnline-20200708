//
//  AuthenticationSecurityService.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit
import LocalAuthentication


// MARK: Hash Password

func Md5HashPassword(_ password: String) -> String {
    
    return AuthenticationSecurityService().retrieveMd5HashPassword(withOriginalPassword: password)
}

func Sha512HashPassword(_ password: String) -> String {
    
    return AuthenticationSecurityService().retrieveSha512HashPassword(withOriginalPassword: password)
}

func HashPasswordToken(_ userName: String, _ hashPassword: String) -> String {
    
    return AuthenticationSecurityService().retrieveHashPasswordToken(withUserName: userName, sha512PHashPassword: hashPassword)
}


class AuthenticationSecurityService: NSObject {
    
    // MARK: - Private Property
    
    let biometricsKey = "Biometrics_"
    
    // MARK: - Internal Methods

    // MARK: User Name
    
    func retrieveLocalUserLoginUserName() -> String? {
        
        return Q_UserDefaultsObjectGet(USER_LOGIN_NAME_KEY) as? String
    }
    
    func saveLocalUserLogin(userName name: String) {
        
        Q_UserDefaultsObjectReSet(name, USER_LOGIN_NAME_KEY)
    }
    
    func removeLocalUserLoginUserName() {
        
        Q_UserDefaultsObjectRemove(USER_LOGIN_NAME_KEY)
    }
    
    // MARK: User Hash Password
    
    func retrieveLocalUserLoginHashPassword(withUserName userName: String) -> String? {
        
        let userHashPwd = SAMKeychain.password(forService: Bundle.main.bundleIdentifier!,
                                                  account: userName)
        
        let switchStatus = retrieveBiometricsAuthenticationSwitchStatus(withUserName: userName)
        
        if switchStatus == true &&
           userHashPwd != nil   {
            return userHashPwd
        }
        return nil
    }
    
    func saveLocalUserLoginHashPassword(withUserName userName: String, password: String) {
        
        SAMKeychain.setPassword( Sha512HashPassword(password),
                     forService: Bundle.main.bundleIdentifier!,
                        account: userName)
    }
    
    func reSaveLocalUserLoginHashPassword(withUserName userName: String, password: String) {
        
        let switchStatus = retrieveBiometricsAuthenticationSwitchStatus(withUserName: userName)
        
        if switchStatus == true {
            saveLocalUserLoginHashPassword(withUserName: userName, password: password)
        }
    }
    
    func removeLocalUserLoginHashPassword(withUserName userName: String) {
        
        let switchStatus = retrieveBiometricsAuthenticationSwitchStatus(withUserName: userName)
        
        if switchStatus == true {
            SAMKeychain.deletePassword(forService: Bundle.main.bundleIdentifier!,
                                          account: biometricsKey + userName)
        }
        
        let userHashPwd = SAMKeychain.password(forService: Bundle.main.bundleIdentifier!,
                                                  account: userName)
        
        if userHashPwd != nil {
            SAMKeychain.deletePassword(forService: Bundle.main.bundleIdentifier!,
                                          account: userName)
        }
    }
    
    // MARK: Auth Switch Status
    
    func retrieveBiometricsAuthenticationSwitchStatus(withUserName userName: String) -> Bool {
        
        let isEnableBiometrics = SAMKeychain.password(forService: Bundle.main.bundleIdentifier!,
                                                         account: biometricsKey + userName)
        
        if isEnableBiometrics == "\(true)" {
            return true
        }
        return false
    }
    
    func setBiometricsAuthenticationSwitchStatus(withUserName userName: String, isEnable: Bool) -> Bool {
        
        return SAMKeychain.setPassword( isEnable ? "\(true)" : "\(false)",
                            forService: Bundle.main.bundleIdentifier!,
                               account: biometricsKey + userName)
    }
    
    // MARK: - Touch ID / Face ID

    func isDeviceSupportBiometricsAuthentication() -> Bool {
        
        if isDeviceSupportTouchID() == true || isDeviceSupportFaceID() == true {
            return true
        }
        return false
    }

    func isDeviceSupportTouchID() -> Bool {
        
        if Q_SystemVersionIsGreaterThanOrEqualTo_80() == false {
            return false
        }
        
        let context = LAContext()
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil) {
            
            if Q_DeviceIsSimulator() {
                if Q_SystemVersionIsGreaterThanOrEqualTo_110() == true {
                    if Q_DeviceIsiPhoneXSeries() == true {
                        return false
                    }
                    return true
                }
            } else {
                if #available(iOS 11.0, *) {
                    if context.biometryType == .touchID {
                        return true
                    }
                    return false
                }
            }
            return true
        }
        
        return false
    }

    func isDeviceSupportFaceID() -> Bool {
        
        if Q_SystemVersionIsGreaterThanOrEqualTo_110() == false {
            return false
        }
        
        let context = LAContext()
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil) ||
           context.canEvaluatePolicy(.deviceOwnerAuthentication, error: nil) {
            
            if Q_DeviceIsSimulator() {
                if Q_SystemVersionIsGreaterThanOrEqualTo_110() == true {
                    if Q_DeviceIsiPhoneXSeries() == true {
                        return true
                    }
                    return false
                }
            } else {
                if #available(iOS 11.0, *) {
                    if context.biometryType == .faceID {
                        return true
                    }
                    return false
                }
            }
            return false
        }
        
        return false
    }
    
    func evaluateBiometrics(withLocalizedReason reason: String!,
                                  success successBlock: ((_ success: Bool) -> Void)?,
                                  failure failureBlock: ((_ error: Error?) -> Void)?) {
        
        let policy: LAPolicy!
        
        let context = LAContext()
        
        if context.canEvaluatePolicy(.deviceOwnerAuthentication, error: nil) {
            policy = .deviceOwnerAuthentication
        } else if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil) {
            policy = .deviceOwnerAuthenticationWithBiometrics
        } else {
            if failureBlock != nil {
                failureBlock!(kLAErrorTouchIDNotAvailable as? Error)
            }
            return
        }
        
        context.evaluatePolicy(policy, localizedReason: reason) { (success: Bool, error: Error?) in
            
            if success == true {
                if successBlock != nil {
                    successBlock!(true)
                }
            } else {
                if failureBlock != nil {
                    failureBlock!(error)
                }
            }
        }
    }
    
    // MARK: Hash Password
    
    func retrieveMd5HashPassword(withOriginalPassword password: String) -> String {
        
        let md5Pwd = password.q_md5()
        
        return md5Pwd
    }
    
    func retrieveSha512HashPassword(withOriginalPassword password: String) -> String {
        
        var sha512Pwd = password
        
        for _ in 0..<1821 {
            sha512Pwd = sha512Pwd.q_sha512()
        }
        
        return sha512Pwd
    }
    
    func retrieveHashPasswordToken(withUserName userName: String, sha512PHashPassword hashPassword: String) -> String {
        
        let timeStampWithin5Minutes = "\(Int(Date().timeIntervalSince1970) / 300)"
        
        var passwordToken: String = userName.lowercased() + timeStampWithin5Minutes
        
        for _ in 0..<607 {
            passwordToken = passwordToken.q_hmacSHA512String(withKey: hashPassword)
        }
        
        return passwordToken
    }
    
    
}
