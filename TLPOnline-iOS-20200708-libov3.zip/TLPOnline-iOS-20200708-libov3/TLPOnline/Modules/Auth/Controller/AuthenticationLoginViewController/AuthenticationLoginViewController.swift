//
//  AuthenticationLoginViewController.swift
//  TLPOnline
//
//  Created by LIBO on 2020/07/06.
//  Refer to the origianl version of TLPOnline-iOS-202003170B-backup-qianqia
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import AlamofireImage

class AuthenticationLoginViewController: PublicBaseViewController, UITextFieldDelegate {
    
    // MARK: - IBOutlet Property
    
    @IBOutlet weak var serverAddressPromptLabel: UILabel!
    @IBOutlet weak var accountPromptLabel: UILabel!
    @IBOutlet weak var passwordPromptLabel: UILabel!
    
    @IBOutlet weak var codePromptLabel: UILabel!
    
    @IBOutlet weak var serverAddressTextField: UITextField!
    @IBOutlet weak var accountTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var InputTextField: UITextField!
    
    @IBOutlet weak var InitButton: UIButton!
    
    var ServerString = ""
    
    
    @IBAction func ReNew(_ sender: UIButton) {
       
        
        let lastLoginServerAddress = Q_UserDefaultsObjectGet(API_ROOT_URL_KEY) as? String ?? API_ROOT_DEFAULT_URL
        
        let Original_Server = "\(lastLoginServerAddress)" + "\(API_VALIDATION_CODE_PATH)"
        
        let Renew_Server = "\(ServerString)"
        
        var New_Server = ""
        
        print("New Server String")
        
        if Renew_Server.q_length() > 0{
            New_Server = "\(ServerString)"+"\(API_VALIDATION_CODE_PATH)"
        }
        else if lastLoginServerAddress.q_length() > 0{
            New_Server = Original_Server
        }
        
//        if lastLoginServerAddress.q_length() > 0{
//            New_Server = Original_Server
//        }
//        else{
//            New_Server = "\(ServerString)"+"\(API_VALIDATION_CODE_PATH)"
//        }
//        New_Server = "\(ServerString)"+"\(API_VALIDATION_CODE_PATH)"
        
        print(New_Server)
        
        
        Alamofire.request(New_Server).responseImage { response in
                    debugPrint(response)

                    print(response.request)
                    print(response.response)
                    debugPrint(response.result)

                    if case .success(let imagepng) = response.result {
                        print("image downloaded: \(imagepng)")
        //                sender.setTitle("",for:.normal)
                        sender.setBackgroundImage(imagepng, for: .normal)
                    }
                }
    }
    
    @IBOutlet weak var loginButton: UIButton!
    
    // MARK: - Private Property
    
    // View
    
    enum TargetViewTag: Int {
        case serverAddress = 0
        case account = 1
        case password = 2
        case code = 3
        case uuid = 4
    }

    var textFields: [UITextField] {
        return [
            self.serverAddressTextField,
            self.accountTextField,
            self.passwordTextField,
            self.InputTextField
        ]
    }
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        InputTextField.delegate = self
        serverAddressTextField.addTarget(self, action: #selector(textDidChange(_:)), for: .allEditingEvents)
        
        print("The New String")
           
        print(ServerString)
        
        print(API_VALIDATION_CODE_PATH)
        
        
        Alamofire.request("https://cis.comac.cc:8016/api/validationcode/").responseImage { response in
                    debugPrint(response)

                    print(response.request)
                    print(response.response)
                    debugPrint(response.result)

                    if case .success(let imagepng) = response.result {
                        print("image downloaded: \(imagepng)")
        //                sender.setTitle("",for:.normal)
                          self.InitButton.setBackgroundImage(imagepng, for: .normal)
                    }
                }
    }
    
    @objc func textDidChange(_ serverAddressTextField:UITextField) {
        print("event:\(serverAddressTextField.text ?? "http://115.28.186.121:5677")")
        ServerString = "\(serverAddressTextField.text ?? "http://115.28.186.121:5677")"
        print(ServerString)
    }
    
    func serverAddressTextField(_ serverAddressTextField: UITextField, shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool {
        let currentText = serverAddressTextField.text ?? ""
        let newText = (currentText as NSString).replacingCharacters(in: range, with: string)
        
        
        print(newText)
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Init View
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.initNavigationBar()
        self.initServerAddressTextField()
        self.initAccountTextField()
        self.initTextField()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //initKeyboardStatus()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    // MARK: - User Event Handle
    
    // MARK: Click
    
    @IBAction func loginButtonDidClick(_ sender: UIButton) {
        
        if !ServerAddressIsValid(self.serverAddressTextField.text) ||
            !AccountIsValid(self.accountTextField.text) ||
            !PasswordIsValid(self.passwordTextField.text) || !CodeIsValid(self.InputTextField.text){
            
            if !ServerAddressIsValid(self.serverAddressTextField.text) {
                self.serverAddressPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.serverAddress")
            }
            if !AccountIsValid(self.accountTextField.text) {
                self.accountPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.account")
            }
            if !PasswordIsValid(self.passwordTextField.text) {
                self.passwordPromptLabel.text = Q_LocalizedString("Auth.verifyMsg.password")
            }
            if !CodeIsValid(self.InputTextField.text) {
                
                self.codePromptLabel.text = Q_LocalizedString("Auth.verifyMsg.code")
                self.codePromptLabel.textColor = UIColor.red
            }
            return
        }
        
        self.setServerAddress()
        
        login()
    }
    
    // MARK: Editing Changed
    
    @objc func textFieldDidChanged(textField: UITextField) {

        switch textField.tag {
            
            case TargetViewTag.serverAddress.rawValue:
                if self.serverAddressPromptLabel.text != "" {
                    setPromptMsg(withTag: textField.tag)
                }

            case TargetViewTag.account.rawValue:
                if self.accountPromptLabel.text != "" {
                    setPromptMsg(withTag: textField.tag)
                }

            case TargetViewTag.password.rawValue:
                if self.passwordPromptLabel.text != "" {
                    setPromptMsg(withTag: textField.tag)
                }
            case TargetViewTag.code.rawValue:
                if self.codePromptLabel.text != "" {
            setPromptMsg(withTag: textField.tag)
            }

            default:
                break
        }
    }
    
    // MARK: - login

    func login() {

        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Auth.logining"), true)
        let InstaransObject:MAC = MAC()
               
        let UUIDinfo = InstaransObject.getUUID()
        
        let password_original = self.passwordTextField.text
        
        let validation_code = self.InputTextField.text
        
        
        let server = self.serverAddressTextField.text
        
        print(server)
        

         AuthenticationLoginDataSourceService()
            .userLogin(withAccount: self.accountTextField.text,
                          password: password_original,
                          uuid: "\(UUIDinfo ?? "unknown_UUID")",
                          validationcode: validation_code,
               success: { (success: Bool, result: [String: Any]?) in
                
                self.showActionResult(toHud: self.hud, withMessage: Q_LocalizedString("Auth.login.success"))
                Q_Dispatch_After(0.5, {
                    self.hideHudMain(hud: self.hud)
                    self.pushToHomeVC()
                })

            }) { (error: Error) in

                self.hideHudMain(hud: self.hud)
                
                let error_info = (error as NSError).userInfo
                
                let error_string = error_info["com.alamofire.serialization.response.error.string"]
                
                let error_json = JSON(error_string)
                
                let str = "\(error_json)"
                
                let index2 = str.index(str.startIndex, offsetBy: 8)
                let index3 = str.index(str.startIndex, offsetBy: 11)
                let code = Int(str[index2...index3])!
                
                print(code)

                switch code {

                    case RequestResponseCode.responseObjectIsEmpty.rawValue:
                        QF_AlertShow_Note_Main(self, RequestResponseCode.loadDataFailure.localValue)
                    
                    case RequestResponseCode.userNameOrPasswordIsInvalid.rawValue:
                        QF_AlertShow_Note_Main(self, RequestResponseCode.userNameOrPasswordIsInvalid.localValue)

                    case RequestResponseCode.CaptchaIsInvalid.rawValue:
                        QF_AlertShow_Note_Main(self, RequestResponseCode.CaptchaIsInvalid.localValue)
                                       
                    case RequestResponseCode.unauthorizedCaptcha.rawValue:
                        QF_AlertShow_Note_Main(self, RequestResponseCode.unauthorizedCaptcha.localValue)
                                       
                    case RequestResponseCode.wrongPasswordOverThreeTimes.rawValue:
                        QF_AlertShow_Note_Main(self, RequestResponseCode.wrongPasswordOverThreeTimes.localValue)
                    
                    

                    default:
                        RequestResponseErrorAlert(error: error,
                                                 target: self,
                                           defaultBlock: {
                                               QF_AlertShow_Note_Main(self, RequestResponseCode.loginFailure.localValue)
                                           })
                }
                
                let lastLoginServerAddress = Q_UserDefaultsObjectGet(API_ROOT_URL_KEY) as? String ?? API_ROOT_DEFAULT_URL
                
                let Original_Server = "\(lastLoginServerAddress)" + "\(API_VALIDATION_CODE_PATH)"
                
                let Renew_Server = "\(self.ServerString)"
                
                var New_Server = ""
                
                print("New Server String")
                
                if Renew_Server.q_length() > 0{
                    New_Server = "\(self.ServerString)"+"\(API_VALIDATION_CODE_PATH)"
                }
                else if lastLoginServerAddress.q_length() > 0{
                    New_Server = Original_Server
                }
                Alamofire.request(New_Server).responseImage { response in
                    if case .success(let imagepng) = response.result {
                        print("image downloaded: \(imagepng)")
                          self.InitButton.setBackgroundImage(imagepng, for: .normal)
                    }
                }
            }
    }

    // MARK: - Navigation Bar

    func initNavigationBar() {
        Q_NavigationBarHideSet(self, true)
    }

    // MARK: - Server Address
    
    func initServerAddressTextField() {
        
        let lastLoginServerAddress = Q_UserDefaultsObjectGet(API_ROOT_URL_KEY) as? String ?? API_ROOT_DEFAULT_URL
        self.serverAddressTextField.text = lastLoginServerAddress
    }
    
    func setServerAddress() {
        
        Q_UserDefaultsObjectSet(self.serverAddressTextField.text!, API_ROOT_URL_KEY)
    }
    
    // MARK: - Account

    func initAccountTextField() {

        let lastLoginUserName = AuthenticationSecurityService().retrieveLocalUserLoginUserName()
        self.accountTextField.text = lastLoginUserName
    }

    func accountIsEmpty() -> Bool {

        if self.accountTextField.text == nil ||
           self.accountTextField.text?.q_length() == 0 {
            return true
        }
        return false
    }

    // MARK: - Prompt Msg

    func setPromptMsg(withTag tag: Int) {

        switch tag {
            
            case TargetViewTag.serverAddress.rawValue:
                if ServerAddressIsValid(self.serverAddressTextField.text) {
                    self.serverAddressPromptLabel.text = ""
                } else {
                    self.serverAddressPromptLabel.text = AuthVerifyMsgType.serverAddress.localValue
                }

            case TargetViewTag.account.rawValue:
                if AccountIsValid(self.accountTextField.text) {
                    self.accountPromptLabel.text = ""
                } else {
                    self.accountPromptLabel.text = AuthVerifyMsgType.account.localValue
                }

            case TargetViewTag.password.rawValue:
                if PasswordIsValid(self.passwordTextField.text) {
                    self.passwordPromptLabel.text = ""
                } else {
                    self.passwordPromptLabel.text = AuthVerifyMsgType.password.localValue
                }
            
            case TargetViewTag.code.rawValue:
               if CodeIsValid(self.InputTextField.text) {
                self.codePromptLabel.text=""
               } else {
                self.codePromptLabel.text=AuthVerifyMsgType.code.localValue
               }
            
            default:
                break
        }
    }

    // MARK: - Text Field

    func initTextField() {

        for tf in self.textFields {

            tf.addTarget( self,
                  action: #selector(textFieldDidChanged(textField:)),
                     for: .editingChanged)
        }
    }

    // MARK: UITextFieldDelegate

    func textFieldDidEndEditing(_ textField: UITextField) {

        setPromptMsg(withTag: textField.tag)
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        switch textField.tag {
            
            case TargetViewTag.serverAddress.rawValue:
                self.accountTextField.becomeFirstResponder()

            case TargetViewTag.account.rawValue:
                self.passwordTextField.becomeFirstResponder()
            
            case TargetViewTag.code.rawValue:
                self.InputTextField.becomeFirstResponder()

            case TargetViewTag.password.rawValue:
                self.passwordTextField.resignFirstResponder()
                login()

            default:
                break
        }

        return true
    }

    // MARK: - Keyboard
    
    func initKeyboardStatus() {
        
        if accountIsEmpty() {
            self.accountTextField.becomeFirstResponder()
        } else {
            self.passwordTextField.becomeFirstResponder()
        }
    }
    
    // MARK: - Navigation
    
    func pushToHomeVC() {
        Q_NotificationPost(USER_LOGIN_AUTHENTICATION_SUCCESS_NOTIFICATION, nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
    }

}
