//
//  SettingsDetailModel.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class SettingsDetailModel: NSObject {
    
    // MARK: - Internal Property
    
    let settingItems: [AccountSettingsType: [[String: Any]]] = [
        
        .language: [
            [
                "title": AccountSettingsType.language.localValue,
                "code": "language",
                "items": [
                    AppSupportLanguageType.sysDefault.localValue,
                    AppSupportLanguageType.zhHans.localValue,
                    AppSupportLanguageType.en.localValue
                ]
            ]
        ],
        
        .changePassword: [
            [
                "title": AccountSettingsType.changePassword.localValue,
                "code": "changePassword",
                "items": [
                    ChangePasswordType.newPassword.localValue
                ]
            ]
        ]
    ]

}
