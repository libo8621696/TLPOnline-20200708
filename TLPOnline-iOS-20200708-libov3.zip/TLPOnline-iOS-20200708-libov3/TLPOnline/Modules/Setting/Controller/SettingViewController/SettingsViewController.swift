//
//  SettingsViewController.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class SettingsViewController: PublicBaseViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Internal Property
    
    
    // MARK: - IBOutlet Property
    
    @IBOutlet weak var tableView: UITableView!
    
    // MARK: - Private Property
    
    // Data
    var showingDatas: [[String: Any]]!
    var settingType: AccountSettingsType = .none
    var currentSelectdIndexPath: IndexPath?
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Init View
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        initNavigationBar()
        initShowingDatas()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        setNavigationBarLogo()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    // MARK: - Showing Datas
    
    func initShowingDatas() {
        
        self.showingDatas = SettingsDataSourceService().loadSettingsItemDatas()
    }
    
    // MARK: - User Event Handle
    
    // MARK: Click
    
    func settingsItemsDidClick(withTitle title: String) {
        
        self.settingType = AccountSettingsType(localValue: title) ?? .none
        
        if self.settingType == .logOut {
            logout(withClearLocalCacheDatas: true)
        }  else {
            self.pushToSettingsDetailVC()
        }
    }
    
    // MARK: - Log Out
    
    func logout(withClearLocalCacheDatas clear: Bool) {

        self.hud = QM_MB_HUD_SHOW_MAIN(self, Q_LocalizedString("Auth.logouting"), true)
        
        AuthenticationLogoutDataSourceService()
            .userLogout(success: { (success: Bool, result: [String: Any]?) in

                self.showActionResult(toHud: self.hud, withMessage: Q_LocalizedString("Auth.logout.success"))

                Q_Dispatch_After(1, {
                    self.hideHudMain(hud: self.hud)
                    self.pushToLoginVC()
                })

            }) { (error: Error) in

                self.hideHudMain(hud: self.hud)
                switch (error as NSError).code {
                    default:
                        RequestResponseErrorAlert(error: error,
                                                 target: self,
                                           defaultBlock: {
                                               QF_AlertShow_Note_Main(self, RequestResponseCode.logoutFailure.localValue)
                                           })
                }
            }
    }
    
    // MARK: - Navigation Bar
    
    func initNavigationBar() {
        
        Q_NavigationBarTitleSet(self, Q_LocalizedString("Setting.title"))
    }
    
    func setNavigationBarLogo() {
        
//        let image = UIImage(named: "icon-logo-r")
//        Q_NavigationBarLeftImageButtonSet_image(self, image, nil)
//        Q_NavigationBarLeftBarButtonItem(self)?.isEnabled = false
    }
    
    // MARK: - Table View

    // MARK: UITableViewDataSource, UITableViewDelegate

    func numberOfSections(in tableView: UITableView) -> Int {

        return (self.showingDatas != nil) ? self.showingDatas.count : 0
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        let items: [String] = self.showingDatas[section]["items"] as! [String]
        return items.count
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {

        return 32
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        var cell = UITableViewCell()

        let code: String = self.showingDatas[indexPath.section]["code"] as! String

        switch code {

            case "general":
                cell = SettingsTableViewCell.cell(tableView, identifier: "settingsItemsCell")
                cell.textLabel?.text = (self.showingDatas[indexPath.section]["items"] as! Array)[indexPath.row]

            case "logout":
                cell = SettingsTableViewCell.cell(tableView, identifier: "settingsLogOutCell")
                (cell as! SettingsTableViewCell).textCenterLabel?.text = (self.showingDatas[indexPath.section]["items"] as! Array)[indexPath.row]

            default:
                break
        }

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        tableView.deselectRow(at: indexPath, animated: true)

        self.currentSelectdIndexPath = indexPath

        var rowStr = tableView.cellForRow(at: indexPath)?.textLabel?.text
        if rowStr == nil {
            rowStr = (tableView.cellForRow(at: indexPath) as! SettingsTableViewCell).textCenterLabel?.text
        }

        settingsItemsDidClick(withTitle: rowStr!)
    }
  
    // MARK: - Navigation
    
    func pushToLoginVC() {
        
        Q_NotificationPost(USER_LOGOUT_AUTHENTICATION_SUCCESS_NOTIFICATION, nil)
    }
    
    func pushToSettingsDetailVC() {
        
        QF_PresentViewControllerWithSegueIdentifier(self, .settingsDetail)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
       
        let vc: UIViewController = segue.destination
        
        switch vc {
            
            case is SettingsDetailViewController:
                let v: SettingsDetailViewController = vc as! SettingsDetailViewController
                v.settingType = self.settingType
                v.titleStr = (self.showingDatas[self.currentSelectdIndexPath!.section]["items"] as! Array)[self.currentSelectdIndexPath!.row]
            
            default:
                break
        }
    }
    
}
