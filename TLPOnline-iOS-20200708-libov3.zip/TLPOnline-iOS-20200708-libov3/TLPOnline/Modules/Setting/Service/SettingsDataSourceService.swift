//
//  SettingDataSourceService.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/12.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class SettingsDataSourceService: NSObject {
    
    // MARK: - Internal Methods
    
    // MARK:  Setting
    
    func loadSettingsItemDatas() -> [[String: Any]] {
        
        return SettingsModel().settingItems
    }
    
    func loadSettingsDetailItemDatas(WithSettingType type: AccountSettingsType) -> [[String: Any]] {
        
        return SettingsDetailModel().settingItems[type]!
    }
    
}
