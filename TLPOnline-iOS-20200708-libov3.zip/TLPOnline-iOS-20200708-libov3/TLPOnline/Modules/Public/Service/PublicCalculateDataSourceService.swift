//
//  PublicCalculateDataSourceService.swift
//  TLPOnline
//
//  Created by Qian Chia on 2019/11/18.
//  Copyright © 2019 COMAC. All rights reserved.
//

import UIKit

class PublicCalculateDataSourceService: NSObject {
    
    // MARK: - Internal Methods
    
    // MARK: Calculate
    
    func calculate(withType type: CalculateType,
                          params: CalculateParamModel,
            success successBlock: ((_ result: CalculateResultModel) -> Void)?,
            failure failureBlock: ((_ error: Error) -> Void)?) {

        ApiClient.DefaultClient()
            .calculatePerformanceData(withCalculateType: type,
                                    calculateParamDatas: params,
            success: { (result: [String : Any]?) in

                let (isEmpty, error) = RequestResponseResultDictonaryObjectEmptyValidate(result: result)
                if isEmpty == true {
                    if failureBlock != nil {
                        failureBlock!(error!)
                    }
                    return
                }
                
                let calculateResultDataDic: [String: Any] = (result!["result"] as? [String: Any])!

                let calculateResultModel  = CalculateResultModel(withDict: calculateResultDataDic)
                
                if successBlock != nil {
                    successBlock!(calculateResultModel)
                }

            }, failure: { (error: Error?) in

                let err = RequestResponseErrorNullObjectValidate(error: error)
                if failureBlock != nil {
                    failureBlock!(err)
                }
            })
    }
    
}
