//
//  UUID.h
//  UUID
//
//  Created by ThomasYang on 16/6/28.
//  Copyright © 2016年 yunzujia. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UUID : NSObject

+(NSString *)getUUID;

@end
